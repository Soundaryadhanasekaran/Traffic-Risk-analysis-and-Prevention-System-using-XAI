# Smart Traffic Accident Risk Prediction and Prevention System
# Business Intelligence Project
