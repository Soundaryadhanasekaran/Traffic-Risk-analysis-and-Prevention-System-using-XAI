"""
Prevention Engine – Recommendations & Alerts
=============================================
Generates actionable prevention recommendations and automatic
alerts based on risk scores, predictions, and explanations.

Categories of interventions:
    • Infrastructure improvements
    • Enforcement actions
    • Public awareness campaigns
    • Emergency resource deployment
    • Temporal advisories (time-based warnings)
"""

import pandas as pd
import numpy as np
from datetime import datetime


# ---------------------------------------------------------------------------
# Recommendation Rules
# ---------------------------------------------------------------------------
INFRASTRUCTURE_RULES = {
    "no_signal": {
        "condition": lambda row: not row.get("has_traffic_signal", True),
        "rec": "Install traffic signals at this intersection",
        "priority": "High",
        "category": "Infrastructure",
    },
    "no_light": {
        "condition": lambda row: not row.get("has_street_light", True),
        "rec": "Install street lighting to improve night-time visibility",
        "priority": "High",
        "category": "Infrastructure",
    },
    "no_cctv": {
        "condition": lambda row: not row.get("has_cctv", True),
        "rec": "Deploy CCTV surveillance for monitoring and deterrence",
        "priority": "Medium",
        "category": "Infrastructure",
    },
    "high_speed": {
        "condition": lambda row: row.get("speed_limit_kmph", 0) >= 80,
        "rec": "Consider reducing speed limit or adding speed breakers",
        "priority": "High",
        "category": "Infrastructure",
    },
    "school_zone": {
        "condition": lambda row: row.get("near_school_hospital", False),
        "rec": "Add school/hospital zone signage and pedestrian crossings",
        "priority": "Critical",
        "category": "Infrastructure",
    },
}

ENFORCEMENT_RULES = {
    "high_violations": {
        "condition": lambda row: row.get("total_violations", 0) > 200,
        "rec": "Increase traffic police patrol frequency",
        "priority": "High",
        "category": "Enforcement",
    },
    "drunk_driving": {
        "condition": lambda row: row.get("pct_drunk", 0) > 0.1,
        "rec": "Set up regular breathalyzer checkpoints",
        "priority": "Critical",
        "category": "Enforcement",
    },
    "speeding": {
        "condition": lambda row: row.get("pct_speeding", 0) > 0.2,
        "rec": "Install speed cameras and radar enforcement",
        "priority": "High",
        "category": "Enforcement",
    },
    "repeat_offenders": {
        "condition": lambda row: row.get("pct_repeat_offender", 0) > 0.25,
        "rec": "Implement stricter penalties for repeat offenders in this area",
        "priority": "High",
        "category": "Enforcement",
    },
}


# ---------------------------------------------------------------------------
# Generate recommendations for a single location
# ---------------------------------------------------------------------------
def generate_location_recommendations(location_row: dict) -> list:
    """
    Evaluate all rules against a location's attributes and return
    applicable recommendations.
    """
    recommendations = []
    all_rules = {**INFRASTRUCTURE_RULES, **ENFORCEMENT_RULES}

    for rule_id, rule in all_rules.items():
        try:
            if rule["condition"](location_row):
                recommendations.append({
                    "rule_id": rule_id,
                    "recommendation": rule["rec"],
                    "priority": rule["priority"],
                    "category": rule["category"],
                })
        except (KeyError, TypeError):
            continue

    # Risk-level based recommendations
    risk_score = location_row.get("risk_score", 0)
    if risk_score >= 75:
        recommendations.append({
            "rule_id": "critical_risk",
            "recommendation": "Conduct immediate safety audit and road redesign assessment",
            "priority": "Critical",
            "category": "Safety Audit",
        })
        recommendations.append({
            "rule_id": "emergency_deploy",
            "recommendation": "Pre-position emergency response resources nearby",
            "priority": "Critical",
            "category": "Emergency",
        })
    elif risk_score >= 50:
        recommendations.append({
            "rule_id": "high_risk",
            "recommendation": "Schedule periodic safety review and targeted interventions",
            "priority": "High",
            "category": "Safety Audit",
        })

    # Night-time specific
    pct_night = location_row.get("pct_night", 0)
    if pct_night > 0.4:
        recommendations.append({
            "rule_id": "night_risk",
            "recommendation": "Increase night patrol and improve road reflectors/markings",
            "priority": "High",
            "category": "Temporal",
        })

    # Weather-related
    pct_bad = location_row.get("pct_bad_weather", 0)
    if pct_bad > 0.3:
        recommendations.append({
            "rule_id": "weather_risk",
            "recommendation": "Improve drainage, add anti-skid surfaces, deploy weather warnings",
            "priority": "Medium",
            "category": "Weather",
        })

    return recommendations


# ---------------------------------------------------------------------------
# Batch recommendations for all locations
# ---------------------------------------------------------------------------
def generate_all_recommendations(risk_df: pd.DataFrame) -> pd.DataFrame:
    """
    Generate recommendations for every location in the risk DataFrame.
    Returns a flat DataFrame of all recommendations.
    """
    all_recs = []
    for _, row in risk_df.iterrows():
        recs = generate_location_recommendations(row.to_dict())
        for r in recs:
            r["location_id"] = row["location_id"]
            r["risk_score"] = row.get("risk_score", 0)
            r["risk_level"] = row.get("risk_level", "Unknown")
            all_recs.append(r)

    recs_df = pd.DataFrame(all_recs)
    if recs_df.empty:
        return recs_df

    # Sort by priority
    priority_order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    recs_df["priority_rank"] = recs_df["priority"].map(priority_order)
    recs_df = recs_df.sort_values(["priority_rank", "risk_score"],
                                   ascending=[True, False]).reset_index(drop=True)
    recs_df = recs_df.drop(columns=["priority_rank"])
    return recs_df


# ---------------------------------------------------------------------------
# Alert Generator
# ---------------------------------------------------------------------------
def generate_alerts(risk_df: pd.DataFrame,
                    threshold_critical: float = 75,
                    threshold_high: float = 50) -> list:
    """
    Generate automatic alerts for locations exceeding risk thresholds.
    """
    alerts = []
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    critical = risk_df[risk_df["risk_score"] >= threshold_critical]
    for _, row in critical.iterrows():
        alerts.append({
            "timestamp": timestamp,
            "alert_level": "🔴 CRITICAL",
            "location_id": row["location_id"],
            "zone": row.get("zone", ""),
            "risk_score": row["risk_score"],
            "message": f"CRITICAL RISK at {row['location_id']} "
                       f"(Risk Score: {row['risk_score']:.1f}). "
                       f"Immediate intervention required.",
        })

    high = risk_df[(risk_df["risk_score"] >= threshold_high) &
                    (risk_df["risk_score"] < threshold_critical)]
    for _, row in high.iterrows():
        alerts.append({
            "timestamp": timestamp,
            "alert_level": "🟠 HIGH",
            "location_id": row["location_id"],
            "zone": row.get("zone", ""),
            "risk_score": row["risk_score"],
            "message": f"HIGH RISK at {row['location_id']} "
                       f"(Risk Score: {row['risk_score']:.1f}). "
                       f"Schedule review and patrols.",
        })

    return alerts


# ---------------------------------------------------------------------------
# Resource Allocation Suggestion
# ---------------------------------------------------------------------------
def suggest_resource_allocation(risk_df: pd.DataFrame,
                                 total_patrol_units: int = 50,
                                 total_ambulances: int = 20) -> pd.DataFrame:
    """
    Suggest optimal resource distribution across zones based on risk.
    """
    zone_risk = risk_df.groupby("zone").agg(
        avg_risk=("risk_score", "mean"),
        max_risk=("risk_score", "max"),
        num_locations=("location_id", "count"),
        total_accidents=("total_accidents", "sum"),
    ).reset_index()

    zone_risk["risk_weight"] = zone_risk["avg_risk"] / zone_risk["avg_risk"].sum()
    zone_risk["suggested_patrols"] = np.round(
        zone_risk["risk_weight"] * total_patrol_units).astype(int)
    zone_risk["suggested_ambulances"] = np.round(
        zone_risk["risk_weight"] * total_ambulances).astype(int)

    # Ensure minimums
    zone_risk["suggested_patrols"] = zone_risk["suggested_patrols"].clip(lower=2)
    zone_risk["suggested_ambulances"] = zone_risk["suggested_ambulances"].clip(lower=1)

    return zone_risk.sort_values("avg_risk", ascending=False).reset_index(drop=True)
