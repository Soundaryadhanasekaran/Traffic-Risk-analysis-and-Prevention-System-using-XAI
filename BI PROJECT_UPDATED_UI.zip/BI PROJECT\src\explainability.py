"""
Explainable AI Module
======================
Uses SHAP (SHapley Additive exPlanations) to provide interpretable
explanations for model predictions. This module:

    1. Generates global feature importance (SHAP summary)
    2. Produces per-location explanations
    3. Creates human-readable risk factor reports

This increases transparency and trust for traffic authorities.
"""

import numpy as np
import pandas as pd

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("⚠  SHAP not installed. Install with: pip install shap")


# ---------------------------------------------------------------------------
# SHAP Explanations
# ---------------------------------------------------------------------------
def compute_shap_values(model_result: dict) -> dict:
    """
    Compute SHAP values for the trained model.

    Parameters
    ----------
    model_result : dict returned by `train_accident_predictor`.

    Returns
    -------
    dict with shap_values, expected_value, and feature_names.
    """
    if not SHAP_AVAILABLE:
        return _fallback_feature_importance(model_result)

    model = model_result["model"]
    X_test = model_result["X_test"]
    feature_names = model_result["feature_names"]

    # Use TreeExplainer for tree-based models, KernelExplainer otherwise
    model_type = type(model).__name__
    try:
        if model_type in ["RandomForestClassifier", "GradientBoostingClassifier"]:
            explainer = shap.TreeExplainer(model)
            shap_values = explainer.shap_values(X_test)
            # For binary classification, take class-1 SHAP values
            if isinstance(shap_values, list):
                shap_values = shap_values[1]
            elif shap_values.ndim == 3:
                shap_values = shap_values[:, :, 1]
            expected_value = explainer.expected_value
            if isinstance(expected_value, (list, np.ndarray)):
                expected_value = expected_value[1] if len(expected_value) > 1 else expected_value[0]
        else:
            # KernelExplainer for linear models (sample background for speed)
            background = shap.sample(X_test, min(100, len(X_test)))
            explainer = shap.KernelExplainer(model.predict_proba, background)
            shap_values = explainer.shap_values(X_test[:200])
            if isinstance(shap_values, list):
                shap_values = shap_values[1]
            elif shap_values.ndim == 3:
                shap_values = shap_values[:, :, 1]
            expected_value = explainer.expected_value
            if isinstance(expected_value, (list, np.ndarray)):
                expected_value = expected_value[1] if len(expected_value) > 1 else expected_value[0]
    except Exception:
        return _fallback_feature_importance(model_result)

    return {
        "shap_values": shap_values,
        "expected_value": expected_value,
        "X_test": X_test,
        "feature_names": feature_names,
        "explainer": explainer,
    }


def _fallback_feature_importance(model_result: dict) -> dict:
    """Fallback when SHAP is unavailable – use model's built-in importances."""
    return {
        "shap_values": None,
        "expected_value": None,
        "X_test": model_result["X_test"],
        "feature_names": model_result["feature_names"],
        "feature_importances": model_result["feature_importances"],
        "explainer": None,
    }


# ---------------------------------------------------------------------------
# Global Feature Importance
# ---------------------------------------------------------------------------
def global_feature_importance(shap_result: dict) -> pd.DataFrame:
    """
    Compute mean absolute SHAP value per feature (global importance).
    Falls back to model importances if SHAP is unavailable.
    """
    if shap_result.get("shap_values") is not None:
        mean_abs = np.abs(shap_result["shap_values"]).mean(axis=0)
        imp_df = pd.DataFrame({
            "feature": shap_result["feature_names"],
            "mean_abs_shap": mean_abs,
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)
    else:
        imp = shap_result.get("feature_importances", {})
        imp_df = pd.DataFrame({
            "feature": list(imp.keys()),
            "importance": list(imp.values()),
        }).sort_values("importance", ascending=False).reset_index(drop=True)

    return imp_df


# ---------------------------------------------------------------------------
# Per-instance (location) explanation
# ---------------------------------------------------------------------------
def explain_location(shap_result: dict, index: int) -> pd.DataFrame:
    """
    Explain the prediction for a single instance (location-month).

    Returns a DataFrame of features sorted by their SHAP contribution.
    """
    if shap_result.get("shap_values") is None:
        return pd.DataFrame({"info": ["SHAP unavailable; install shap package"]})

    sv = shap_result["shap_values"][index]
    fv = shap_result["X_test"][index]

    explanation = pd.DataFrame({
        "feature": shap_result["feature_names"],
        "feature_value": fv,
        "shap_value": sv,
        "abs_shap": np.abs(sv),
        "direction": ["↑ Increases Risk" if s > 0 else "↓ Decreases Risk"
                       for s in sv],
    }).sort_values("abs_shap", ascending=False).reset_index(drop=True)

    return explanation


# ---------------------------------------------------------------------------
# Human-readable risk report
# ---------------------------------------------------------------------------
def generate_risk_explanation(shap_result: dict, index: int,
                               location_name: str = "Location") -> str:
    """
    Generate a human-readable explanation for a location's risk prediction.
    """
    exp = explain_location(shap_result, index)
    if "info" in exp.columns:
        return "SHAP explanations unavailable."

    top_factors = exp.head(5)

    lines = [f"📋 Risk Explanation for {location_name}",
             "=" * 50]
    for _, row in top_factors.iterrows():
        direction = "INCREASES" if row["shap_value"] > 0 else "DECREASES"
        lines.append(
            f"  • {row['feature']} = {row['feature_value']:.2f}  →  "
            f"{direction} risk (impact: {row['abs_shap']:.4f})"
        )
    lines.append("=" * 50)
    return "\n".join(lines)
