"""
Smart Traffic Accident Risk Prediction and Prevention System
=============================================================
Main entry point – runs the complete BI pipeline:
    1. Generate synthetic data
    2. Compute risk scores
    3. Detect black spots (spatial clustering)
    4. Train ML prediction models
    5. Generate SHAP explanations
    6. Produce prevention recommendations
    7. Export reports

Run: python main.py
Dashboard: streamlit run dashboard/app.py
"""

import os
import sys
import warnings

import numpy as np
import pandas as pd

# Ensure src is on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.data_generator import generate_all_data
from src.risk_scoring import compute_risk_scores, compute_hourly_risk_matrix
from src.spatial_clustering import (detect_blackspots_dbscan,
                                     zone_clustering, blackspot_summary)
from src.prediction_model import (prepare_features, train_accident_predictor,
                                   compare_models, identify_high_risk_periods)
from src.explainability import (compute_shap_values, global_feature_importance,
                                 generate_risk_explanation)
from src.prevention_engine import (generate_all_recommendations,
                                    generate_alerts,
                                    suggest_resource_allocation)
from src.utils import export_report

warnings.filterwarnings("ignore")


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def main():
    DATA_DIR = "data"
    REPORT_DIR = "reports"

    # ==================================================================
    # STEP 1: Generate / Load Data
    # ==================================================================
    separator("STEP 1: Data Generation")
    datasets = generate_all_data(DATA_DIR)
    locations = datasets["locations"]
    accidents = datasets["accidents"]
    violations = datasets["violations"]

    # ==================================================================
    # STEP 2: Risk Scoring
    # ==================================================================
    separator("STEP 2: Dynamic Risk Scoring")
    risk_df = compute_risk_scores(accidents, violations, locations)
    print(f"\nRisk Score Statistics:")
    print(risk_df["risk_score"].describe().to_string())
    print(f"\nRisk Level Distribution:")
    print(risk_df["risk_level"].value_counts().to_string())
    export_report(risk_df, "risk_scores.csv", REPORT_DIR)

    # ==================================================================
    # STEP 3: Spatial Clustering (Black Spots)
    # ==================================================================
    separator("STEP 3: Black Spot Detection")
    risk_df = detect_blackspots_dbscan(risk_df)
    risk_df = zone_clustering(risk_df)
    bs = blackspot_summary(risk_df)
    if not bs.empty:
        print(f"\nDetected {len(bs)} black-spot clusters:")
        print(bs[["blackspot_cluster", "num_locations", "avg_risk_score",
                   "total_accidents"]].to_string(index=False))
        export_report(bs, "blackspot_clusters.csv", REPORT_DIR)
    else:
        print("No black-spot clusters detected.")

    # ==================================================================
    # STEP 4: ML Prediction Models
    # ==================================================================
    separator("STEP 4: Machine Learning Prediction")
    features_df = prepare_features(accidents, violations, locations)
    print(f"Feature matrix: {features_df.shape[0]:,} rows × {features_df.shape[1]} columns")

    # Train & compare models
    comparison = compare_models(features_df)
    print(f"\n📊 Model Comparison:")
    print(comparison.to_string())
    export_report(comparison.reset_index(), "model_comparison.csv", REPORT_DIR)

    # Best model details
    result_rf = train_accident_predictor(features_df, model_type="rf")
    print(f"\n🏆 Random Forest Metrics:")
    for k, v in result_rf["metrics"].items():
        print(f"   {k}: {v}")

    # High-risk periods
    hrp = identify_high_risk_periods(accidents)
    print(f"\n⏰ Top 5 High-Risk Periods:")
    print(hrp.head(5).to_string(index=False))
    export_report(hrp, "high_risk_periods.csv", REPORT_DIR)

    # Feature importances
    imp = result_rf["feature_importances"]
    imp_sorted = sorted(imp.items(), key=lambda x: x[1], reverse=True)
    print(f"\n🔑 Top 10 Feature Importances:")
    for feat, val in imp_sorted[:10]:
        print(f"   {feat:35s}  {val:.4f}")

    # ==================================================================
    # STEP 5: Explainable AI
    # ==================================================================
    separator("STEP 5: Explainable AI (SHAP)")
    try:
        shap_result = compute_shap_values(result_rf)
        imp_df = global_feature_importance(shap_result)
        print("Global Feature Importance (SHAP):")
        print(imp_df.head(10).to_string(index=False))
        export_report(imp_df, "shap_feature_importance.csv", REPORT_DIR)

        # Sample explanation
        print(f"\n{generate_risk_explanation(shap_result, 0, 'Sample Location')}")
    except Exception as e:
        print(f"SHAP analysis skipped: {e}")
        print("Install SHAP with: pip install shap")

    # ==================================================================
    # STEP 6: Prevention Recommendations
    # ==================================================================
    separator("STEP 6: Prevention Recommendations")
    recs_df = generate_all_recommendations(risk_df)
    print(f"Generated {len(recs_df):,} recommendations across {recs_df['location_id'].nunique()} locations")
    print(f"\nRecommendations by Priority:")
    print(recs_df["priority"].value_counts().to_string())
    print(f"\nRecommendations by Category:")
    print(recs_df["category"].value_counts().to_string())
    export_report(recs_df, "prevention_recommendations.csv", REPORT_DIR)

    # Alerts
    alerts = generate_alerts(risk_df)
    print(f"\n🚨 Active Alerts: {len(alerts)}")
    for a in alerts[:5]:
        print(f"   {a['alert_level']} | {a['location_id']} | Score: {a['risk_score']}")

    # Resource allocation
    alloc = suggest_resource_allocation(risk_df)
    print(f"\n📦 Resource Allocation Suggestion:")
    print(alloc.to_string(index=False))
    export_report(alloc, "resource_allocation.csv", REPORT_DIR)

    # ==================================================================
    # Summary
    # ==================================================================
    separator("PIPELINE COMPLETE")
    print(f"📁 All reports saved in '{REPORT_DIR}/' directory.")
    print(f"\n📊 To launch the interactive dashboard, run:")
    print(f"   streamlit run dashboard/app.py")
    print()


if __name__ == "__main__":
    main()
