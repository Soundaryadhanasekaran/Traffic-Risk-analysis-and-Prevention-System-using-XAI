# 🚦 Smart Traffic Accident Risk Prediction and Prevention System

A **Business Intelligence** project that combines **Explainable Artificial Intelligence (XAI)** with spatial analysis and predictive modelling to convert historical and real-time traffic data into actionable intelligence for accident prevention.

---

## ✨ NEW FEATURE: User Data Upload

The dashboard now supports **custom dataset uploads**! You can:
- ✅ Upload your own traffic accident data via the UI
- ✅ Use sample synthetic data for testing
- ✅ Switch between datasets without restarting
- ✅ Visualize and analyze any compatible dataset

**Getting Started:**
1. Run the dashboard: `streamlit run dashboard/app.py`
2. Navigate to **"📤 Data Upload"** page
3. Choose "Upload Custom Dataset" or use sample data
4. Upload your CSV files (accidents.csv, violations.csv, locations.csv)
5. The dashboard automatically validates and processes your data
6. Go to **"🏠 Overview"** to see your analysis!

---

## 📌 Project Objectives

| Objective | Technique |
|---|---|
| **Dynamic Risk Scoring** | Weighted composite scoring across accident rates, severity, violations, time & environment |
| **Black Spot Detection** | DBSCAN spatial clustering on geo-coordinates weighted by risk |
| **Accident Prediction** | Random Forest, Gradient Boosting, Logistic Regression |
| **Explainable AI** | SHAP (SHapley Additive exPlanations) for transparent risk factors |
| **Prevention Recommendations** | Rule-based engine with prioritised interventions |
| **Resource Allocation** | Risk-weighted distribution of patrols & emergency units |

---

## 📂 Project Structure

```
BI PROJECT/
│
├── data/                        # Generated datasets (CSV)
│   ├── locations.csv            # 120 intersections / road segments
│   ├── accidents.csv            # 5,000 historical accident records
│   ├── violations.csv           # 15,000 traffic violation records
│   └── weather.csv              # Hourly weather observations
│
├── src/                         # Core modules
│   ├── __init__.py
│   ├── data_generator.py        # Synthetic data generation
│   ├── risk_scoring.py          # Dynamic risk scoring engine
│   ├── spatial_clustering.py    # DBSCAN & KMeans black-spot detection
│   ├── prediction_model.py      # ML model training & evaluation
│   ├── explainability.py        # SHAP-based explainable AI
│   ├── prevention_engine.py     # Recommendations & alerts
│   └── utils.py                 # Utility functions
│
├── dashboard/                   # Interactive BI dashboard
│   └── app.py                   # Streamlit multi-page dashboard (NOW WITH FILE UPLOAD!)
│
├── reports/                     # Generated analysis reports (CSV)
│
├── main.py                      # Pipeline entry point
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

---

## 🚀 Getting Started

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Full Pipeline

```bash
python main.py
```

This will:
- Generate synthetic traffic data (accidents, violations, locations, weather)
- Compute risk scores for all 120 locations
- Detect black-spot clusters using DBSCAN
- Train 3 ML models and compare performance
- Generate SHAP explanations
- Produce prevention recommendations and alerts
- Export all reports to `reports/`

### 3. Launch the Interactive Dashboard

```bash
streamlit run dashboard/app.py
```

The dashboard has **6 interactive pages**:

| Page | Description |
|---|---|
| 🏠 **Overview** | KPIs, severity distribution, cause analysis, monthly trends |
| 🗺️ **Risk Map** | Geospatial risk map with black-spot clusters |
| 📈 **Trend Analysis** | Temporal patterns, heatmaps, weather impact |
| 🤖 **Prediction & XAI** | Model comparison, SHAP explanations, feature importance |
| 🛡️ **Prevention** | Alert system, filtered recommendations |
| 📋 **Resource Allocation** | Zone-wise patrol and ambulance deployment |
| 📤 **Data Upload** | Upload your custom datasets or use sample data |

---

## 📤 DATA UPLOAD GUIDE

### How to Upload Custom Data

1. **Navigate to Data Upload Page**: Open the dashboard and click on **"📤 Data Upload"**
2. **Choose Data Source**: 
   - Select **"Upload Custom Dataset"** to upload your own files
   - Or select **"Use Sample Dataset"** to use pre-generated data
3. **Upload Files**: Drag and drop or select the required CSV files
4. **Process & Validate**: Click "🚀 Process & Validate Files" button
5. **Review Preview**: Check the data preview tabs to verify your data
6. **Start Analysis**: Navigate to other pages (Overview, Risk Map, etc.) to analyze

### Required CSV Files

#### 1. **accidents.csv** (Required)
Contains historical accident records. Must include these columns:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| accident_id | string | Unique identifier | "ACC-000001" |
| location_id | string | Reference to location | "LOC-0001" |
| date | string | Date in YYYY-MM-DD format | "2023-06-15" |
| hour | integer | Hour of day (0-23) | 14 |
| severity | string | Minor, Moderate, Severe, Fatal | "Severe" |
| num_casualties | integer | Number of injuries | 2 |
| num_fatalities | integer | Number of deaths | 0 |
| primary_vehicle | string | Type of vehicle involved | "Car" |
| cause | string | Reason for accident | "Over Speeding" |
| latitude | float | GPS latitude coordinate | 12.8756 |
| longitude | float | GPS longitude coordinate | 77.6245 |

#### 2. **violations.csv** (Required)
Contains traffic violation records. Must include:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| violation_id | string | Unique identifier | "VIO-000001" |
| location_id | string | Reference to location | "LOC-0001" |
| date | string | Date in YYYY-MM-DD format | "2023-06-15" |
| hour | integer | Hour of day (0-23) | 10 |
| violation_type | string | Type of violation | "Speeding" |
| fine_amount | integer | Fine in currency units | 500 |
| vehicle_type | string | Type of vehicle | "Motorcycle" |
| repeat_offender | boolean | Is repeat offender | true |

#### 3. **locations.csv** (Required)
Contains location/intersection master data. Must include:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| location_id | string | Unique identifier | "LOC-0001" |
| location_name | string | Name of location | "Junction 1" |
| latitude | float | GPS latitude | 12.8756 |
| longitude | float | GPS longitude | 77.6245 |
| zone | string | Zone/district name | "North Zone" |
| road_type | string | Type of road | "Highway" |
| speed_limit_kmph | integer | Speed limit | 60 |
| num_lanes | integer | Number of lanes | 4 |
| has_traffic_signal | boolean | Traffic signal present | true |
| has_cctv | boolean | CCTV camera available | true |

#### 4. **weather.csv** (Optional)
If not provided, default weather data will be auto-generated.

| Column | Type | Description |
|--------|------|-------------|
| date | string | Date in YYYY-MM-DD format |
| hour | integer | Hour of day |
| temperature_c | float | Temperature in Celsius |
| humidity_pct | float | Humidity percentage |
| visibility_km | float | Visibility in kilometers |
| wind_speed_kmph | float | Wind speed |
| weather_condition | string | Clear, Rainy, Foggy, Cloudy, Stormy |

### Data Format Requirements

- ✅ All files must be in **CSV format** (.csv extension)
- ✅ First row must contain column headers
- ✅ Data types must match the specification
- ✅ All required columns must be present
- ✅ No empty/missing values in required columns
- ✅ Date format: YYYY-MM-DD (e.g., 2023-06-15)
- ✅ Boolean values: true/false or 0/1

### Sample Data

The system includes sample synthetic data in the `data/` directory. You can:
1. Download the sample files and use them as templates
2. Select "Use Sample Dataset" on the Data Upload page to visualize with pre-generated data
3. Modify the sample data format to match your real-world dataset

### Data Validation

The dashboard automatically validates:
- ✅ All required files are uploaded
- ✅ All required columns exist
- ✅ Data types are correct
- ✅ No critical errors in records

If validation fails, you'll see helpful error messages explaining what went wrong.

---

## 📊 Key Features

### Dynamic Risk Scoring (0–100)
The composite risk score weighs 7 dimensions:
- **Accident Frequency** (25%) – total accident count per location
- **Severity** (20%) – average severity of historical accidents
- **Violations** (15%) – traffic violation density
- **Infrastructure** (10%) – presence of signals, lights, CCTV
- **Temporal Patterns** (10%) – peak-hour concentration
- **Weather / Road** (10%) – bad weather and wet road proportion
- **Recurrence** (10%) – annual accident rate

### Machine Learning Models
| Model | Features Used |
|---|---|
| Random Forest | 21 features including lag, rolling averages, infrastructure |
| Gradient Boosting | Same feature set – benchmarked for comparison |
| Logistic Regression | Baseline model with standardised features |

### Explainable AI (SHAP)
- **Global importance**: Which features matter most across all predictions
- **Local explanations**: Why a specific location is predicted as high-risk
- **Human-readable reports**: Auto-generated text explanations

### Prevention Engine
- **Rule-based recommendations**: Infrastructure, enforcement, awareness
- **Automatic alerts**: Critical and high-risk threshold warnings
- **Resource allocation**: Optimal distribution of patrols and ambulances

---

## 🛠️ Technologies Used

- **Python 3.9+**
- **Pandas & NumPy** – data processing
- **Scikit-learn** – ML models, clustering, preprocessing
- **SHAP** – explainable AI
- **Plotly** – interactive visualisations
- **Streamlit** – BI dashboard
- **DBSCAN & KMeans** – spatial clustering

---

## 📈 Sample Outputs

After running `python main.py`, you'll see output like:

```
============================================================
  STEP 4: Machine Learning Prediction
============================================================

📊 Model Comparison:
                     accuracy  precision  recall     f1  roc_auc
Random Forest          0.82     0.79      0.76   0.77    0.88
Gradient Boosting      0.81     0.78      0.75   0.76    0.87
Logistic Regression    0.74     0.70      0.68   0.69    0.79
```

---

## 📜 License

This project is developed for academic / educational purposes as part of a Business Intelligence course project.

---

*Smart Traffic Accident Risk Prediction and Prevention System © 2026*
