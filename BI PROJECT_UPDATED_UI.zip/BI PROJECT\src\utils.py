"""
Utility functions for the BI project.
"""

import os
import pandas as pd


def load_datasets(data_dir: str = "data") -> dict:
    """Load all CSV datasets from the data directory."""
    datasets = {}
    for name in ["locations", "accidents", "violations", "weather"]:
        path = os.path.join(data_dir, f"{name}.csv")
        if os.path.exists(path):
            datasets[name] = pd.read_csv(path)
            print(f"  ✓ Loaded {name}: {len(datasets[name]):,} records")
        else:
            print(f"  ✗ {name}.csv not found in {data_dir}/")
    return datasets


def export_report(df: pd.DataFrame, filename: str, output_dir: str = "reports"):
    """Export a DataFrame to CSV in the reports directory."""
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, filename)
    df.to_csv(path, index=False)
    print(f"  📄 Report saved: {path}")
    return path
