# 📤 Quick Start Guide - Data Upload Feature

## 🎯 What's New?

Your dashboard now supports **uploading custom datasets**! You can analyze your own traffic data instead of just using sample data.

---

## ⚡ 5-Minute Quick Start

### Step 1: Start the Dashboard
```bash
streamlit run dashboard/app.py
```
Dashboard opens at: `http://localhost:8501`

### Step 2: Go to Data Upload Page
- Look for the sidebar on the left
- Click on **"📤 Data Upload"** (first navigation option)

### Step 3: Choose Your Data Source

**Option A: Use Sample Data (Fastest)**
- Select: "Use Sample Dataset"
- Click "Overview" page to see analysis
- That's it! ✅

**Option B: Upload Your Own Data**
- Select: "Upload Custom Dataset"
- Upload 3 required CSV files:
  1. `accidents.csv`
  2. `violations.csv`
  3. `locations.csv`
- Click "🚀 Process & Validate Files"
- Click "Overview" to see analysis

---

## 📊 Sample CSV Files

You can download and modify the sample files provided in `data/` folder:

```
data/
├── accidents.csv        ← Download & modify this
├── violations.csv       ← Download & modify this
├── locations.csv        ← Download & modify this
└── weather.csv          ← (Optional - auto-generated if missing)
```

---

## 📝 CSV File Requirements

### accidents.csv
```csv
accident_id,location_id,date,hour,severity,num_casualties,num_fatalities,primary_vehicle,cause,latitude,longitude
ACC-000001,LOC-0001,2023-06-15,14,Severe,2,0,Car,Over Speeding,12.8756,77.6245
ACC-000002,LOC-0002,2023-06-15,15,Minor,0,0,Motorcycle,Signal Jumping,12.8765,77.6250
```

**Required columns**: accident_id, location_id, date, hour, severity, num_casualties, num_fatalities, primary_vehicle, cause, latitude, longitude

### violations.csv
```csv
violation_id,location_id,date,hour,violation_type,fine_amount,vehicle_type,repeat_offender
VIO-000001,LOC-0001,2023-06-15,10,Speeding,500,Motorcycle,false
VIO-000002,LOC-0002,2023-06-15,11,Signal Jumping,1000,Car,true
```

**Required columns**: violation_id, location_id, date, hour, violation_type, fine_amount, vehicle_type, repeat_offender

### locations.csv
```csv
location_id,location_name,latitude,longitude,zone,road_type,speed_limit_kmph,num_lanes,has_traffic_signal,has_cctv
LOC-0001,Junction 1,12.8756,77.6245,North Zone,Highway,60,4,true,true
LOC-0002,Junction 2,12.8765,77.6250,North Zone,Arterial Road,50,2,true,false
```

**Required columns**: location_id, location_name, latitude, longitude, zone, road_type, speed_limit_kmph, num_lanes, has_traffic_signal, has_cctv

---

## ✅ Data Format Checklist

Before uploading, make sure:
- [ ] All files are `.csv` format
- [ ] First row has column headers
- [ ] All required columns exist
- [ ] Date format is `YYYY-MM-DD` (example: 2023-06-15)
- [ ] Numbers are formatted correctly (no currency symbols, commas)
- [ ] Boolean values are `true` or `false`
- [ ] No blank rows at the end
- [ ] File names match exactly: `accidents.csv`, `violations.csv`, `locations.csv`

---

## 🎨 Dashboard Pages

After uploading data, explore these pages:

| Page | What You'll See |
|------|-----------------|
| 🏠 **Overview** | Key metrics, charts, top 10 risky locations |
| 🗺️ **Risk Map** | Interactive map showing risk hot spots |
| 📈 **Trend Analysis** | Patterns by hour, day, month, weather |
| 🤖 **Prediction & XAI** | ML model predictions and explanations |
| 🛡️ **Prevention** | Recommendations for accident prevention |
| 📋 **Resource Allocation** | Optimal police patrol & ambulance placement |

---

## 🐛 Troubleshooting

### Problem: "Missing 'accidents.csv' file"
**Solution**: Make sure you have uploaded a file named exactly `accidents.csv` (case-sensitive)

### Problem: "accidents.csv missing required column: 'location_id'"
**Solution**: Check that your CSV has a column named `location_id`. The dashboard is case-sensitive.

### Problem: "Error processing files"
**Solution**: 
- Check file format is valid CSV
- Open in Excel or notepad to verify
- Make sure no special characters in column names
- Ensure all rows have same number of columns

### Problem: Data loads but visualizations are empty
**Solution**: 
- Check that location_id values match between files
- Verify dates are in YYYY-MM-DD format
- Ensure latitude/longitude are numbers, not text

---

## 💡 Tips & Tricks

1. **Test with Sample Data First**
   - Use sample dataset to understand the dashboard
   - Then upload your own data

2. **Keep File Names Exact**
   - `accidents.csv` (not Accidents.csv or accidents.xlsx)
   - `violations.csv` (not violations_data.csv)
   - `locations.csv` (not location_master.csv)

3. **Validate Locally**
   - Open CSV in Excel/LibreOffice
   - Check for formatting issues
   - Verify required columns exist

4. **Start Small**
   - Upload 100-500 records first
   - Verify it works before uploading large datasets
   - Large datasets may take longer to process

5. **Switch Datasets Easily**
   - Go back to "📤 Data Upload" anytime
   - Select different data source
   - All pages update automatically

---

## 🔄 Workflow Example

```
1. Start dashboard
   └─ streamlit run dashboard/app.py

2. Go to "📤 Data Upload" page

3. Download sample files from data/ folder

4. Modify with your data in Excel

5. Upload your modified CSVs

6. Click "Process & Validate Files"

7. Review data preview

8. Go to "🏠 Overview" page

9. Explore other analysis pages

10. Download reports for presentations
```

---

## 📚 Learn More

- **Full Documentation**: See `README.md`
- **Data Dictionary**: See "📤 Data Upload" page → scroll down → "Data Dictionary" section
- **Examples**: Sample data in `data/` folder

---

## 🆘 Need Help?

1. Check the **Data Dictionary** section in the dashboard
2. Review `README.md` for detailed documentation
3. Look at sample CSV files in `data/` folder as templates
4. Verify error messages on the dashboard - they're helpful!

---

**Happy analyzing! 🎉**

*If you encounter any issues, the dashboard will provide helpful error messages to guide you.*
