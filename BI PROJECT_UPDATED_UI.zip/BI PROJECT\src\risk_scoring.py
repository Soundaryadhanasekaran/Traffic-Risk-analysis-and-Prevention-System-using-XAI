"""
Dynamic Risk Scoring Engine
============================
Computes a composite risk score for every location by aggregating:
    • Historical accident frequency & severity
    • Violation density
    • Temporal patterns (time-of-day, day-of-week, seasonal)
    • Environmental / infrastructure factors

Output: A DataFrame with per-location risk scores (0-100).
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


# ---------------------------------------------------------------------------
# Severity weights
# ---------------------------------------------------------------------------
SEVERITY_WEIGHT = {"Minor": 1, "Moderate": 3, "Severe": 7, "Fatal": 15}


def _accident_features(accidents: pd.DataFrame) -> pd.DataFrame:
    """Aggregate accident statistics per location."""
    acc = accidents.copy()
    acc["severity_score"] = acc["severity"].map(SEVERITY_WEIGHT)

    agg = acc.groupby("location_id").agg(
        total_accidents=("accident_id", "count"),
        total_casualties=("num_casualties", "sum"),
        total_fatalities=("num_fatalities", "sum"),
        avg_severity=("severity_score", "mean"),
        max_severity=("severity_score", "max"),
        avg_vehicles=("num_vehicles_involved", "mean"),
        pct_night=("light_condition", lambda x: (x.isin(["Night-Lit", "Night-Unlit"])).mean()),
        pct_wet_road=("road_surface", lambda x: (x != "Dry").mean()),
        pct_bad_weather=("weather", lambda x: (x.isin(["Rainy", "Foggy", "Stormy"])).mean()),
    ).reset_index()

    # Recurrence rate (accidents per year)
    years = acc["year"].nunique()
    agg["annual_accident_rate"] = agg["total_accidents"] / max(years, 1)

    return agg


def _violation_features(violations: pd.DataFrame) -> pd.DataFrame:
    """Aggregate violation statistics per location."""
    vio = violations.copy()
    agg = vio.groupby("location_id").agg(
        total_violations=("violation_id", "count"),
        pct_speeding=("violation_type", lambda x: (x == "Speeding").mean()),
        pct_signal_jump=("violation_type", lambda x: (x == "Signal Jumping").mean()),
        pct_drunk=("violation_type", lambda x: (x == "Drunk Driving").mean()),
        pct_repeat_offender=("repeat_offender", "mean"),
        avg_fine=("fine_amount", "mean"),
    ).reset_index()
    return agg


def _location_infrastructure(locations: pd.DataFrame) -> pd.DataFrame:
    """Score infrastructure quality (lower = riskier)."""
    loc = locations.copy()
    loc["infra_risk"] = 0
    loc.loc[~loc["has_traffic_signal"], "infra_risk"] += 2
    loc.loc[~loc["has_cctv"], "infra_risk"] += 1
    loc.loc[~loc["has_street_light"], "infra_risk"] += 2
    loc.loc[loc["near_school_hospital"], "infra_risk"] += 1.5
    loc.loc[loc["speed_limit_kmph"] >= 80, "infra_risk"] += 1
    loc.loc[loc["road_type"] == "Highway", "infra_risk"] += 1
    return loc[["location_id", "infra_risk", "speed_limit_kmph", "num_lanes",
                "road_type", "zone"]]


def _temporal_risk(accidents: pd.DataFrame) -> pd.DataFrame:
    """Identify peak-accident hours and days per location."""
    acc = accidents.copy()
    # Peak hour concentration: ratio of accidents in top-3 hours
    def peak_hour_ratio(series):
        counts = series.value_counts(normalize=True)
        return counts.nlargest(3).sum()

    # Weekend ratio
    def weekend_ratio(series):
        return series.isin(["Saturday", "Sunday"]).mean()

    agg = acc.groupby("location_id").agg(
        peak_hour_concentration=("hour", peak_hour_ratio),
        weekend_ratio=("day_of_week", weekend_ratio),
    ).reset_index()
    return agg


# ---------------------------------------------------------------------------
# Composite Risk Score
# ---------------------------------------------------------------------------
COMPONENT_WEIGHTS = {
    "accident_freq":   0.25,
    "severity":        0.20,
    "violations":      0.15,
    "infrastructure":  0.10,
    "temporal":        0.10,
    "weather_road":    0.10,
    "recurrence":      0.10,
}


def compute_risk_scores(accidents: pd.DataFrame,
                        violations: pd.DataFrame,
                        locations: pd.DataFrame) -> pd.DataFrame:
    """
    Compute a composite risk score (0-100) for every location.

    Returns a DataFrame with location_id, individual component scores,
    and the final `risk_score`.
    """
    acc_feats = _accident_features(accidents)
    vio_feats = _violation_features(violations)
    infra_feats = _location_infrastructure(locations)
    temp_feats = _temporal_risk(accidents)

    # Merge all
    df = locations[["location_id", "latitude", "longitude", "zone", "road_type"]].copy()
    df = df.merge(acc_feats, on="location_id", how="left")
    df = df.merge(vio_feats, on="location_id", how="left")
    df = df.merge(infra_feats[["location_id", "infra_risk"]], on="location_id", how="left")
    df = df.merge(temp_feats, on="location_id", how="left")
    df = df.fillna(0)

    # Normalise individual dimensions to 0-1
    scaler = MinMaxScaler()

    score_cols = {
        "accident_freq": "total_accidents",
        "severity": "avg_severity",
        "violations": "total_violations",
        "infrastructure": "infra_risk",
        "temporal": "peak_hour_concentration",
        "weather_road": "pct_bad_weather",
        "recurrence": "annual_accident_rate",
    }

    for key, col in score_cols.items():
        vals = df[[col]].values
        df[f"score_{key}"] = scaler.fit_transform(vals).flatten()

    # Weighted sum → 0-100
    df["risk_score"] = sum(
        df[f"score_{k}"] * w for k, w in COMPONENT_WEIGHTS.items()
    ) * 100

    df["risk_score"] = df["risk_score"].round(2)

    # Risk categories
    df["risk_level"] = pd.cut(
        df["risk_score"],
        bins=[-1, 25, 50, 75, 100],
        labels=["Low", "Medium", "High", "Critical"],
    )

    return df.sort_values("risk_score", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# Time-slot risk matrix
# ---------------------------------------------------------------------------
def compute_hourly_risk_matrix(accidents: pd.DataFrame) -> pd.DataFrame:
    """Create hour × day-of-week accident-count heatmap matrix."""
    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday",
                 "Friday", "Saturday", "Sunday"]
    matrix = accidents.groupby(["day_of_week", "hour"]).size().unstack(fill_value=0)
    matrix = matrix.reindex(day_order)
    return matrix
