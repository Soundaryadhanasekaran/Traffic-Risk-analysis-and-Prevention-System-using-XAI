"""
Spatial Clustering – Black Spot Detection
==========================================
Uses DBSCAN and KMeans clustering on geo-coordinates weighted by
accident frequency/severity to automatically detect accident-prone
zones (black spots).

Output: labelled locations with cluster IDs and a GeoJSON-ready
        summary for map visualization.
"""

import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler


# ---------------------------------------------------------------------------
# DBSCAN-based black spot detection
# ---------------------------------------------------------------------------
def detect_blackspots_dbscan(risk_df: pd.DataFrame,
                              eps_km: float = 2.0,
                              min_samples: int = 2,
                              risk_threshold: float = 20.0) -> pd.DataFrame:
    """
    Identify black-spot clusters using DBSCAN on high-risk locations.

    Parameters
    ----------
    risk_df : DataFrame with latitude, longitude, risk_score columns.
    eps_km  : Maximum neighbourhood radius in km (converted to radians).
    min_samples : Min locations to form a cluster.
    risk_threshold : Only locations with risk_score >= threshold are clustered.

    Returns
    -------
    DataFrame with an added `blackspot_cluster` column (-1 = no cluster).
    """
    high_risk = risk_df[risk_df["risk_score"] >= risk_threshold].copy()
    if high_risk.empty:
        risk_df["blackspot_cluster"] = -1
        return risk_df

    coords = np.radians(high_risk[["latitude", "longitude"]].values)
    eps_rad = eps_km / 6371.0  # Earth radius in km

    db = DBSCAN(eps=eps_rad, min_samples=min_samples, metric="haversine")
    high_risk["blackspot_cluster"] = db.fit_predict(coords)

    risk_df = risk_df.merge(
        high_risk[["location_id", "blackspot_cluster"]],
        on="location_id", how="left"
    )
    risk_df["blackspot_cluster"] = risk_df["blackspot_cluster"].fillna(-1).astype(int)

    return risk_df


# ---------------------------------------------------------------------------
# KMeans zone clustering
# ---------------------------------------------------------------------------
def zone_clustering(risk_df: pd.DataFrame, n_zones: int = 8) -> pd.DataFrame:
    """
    Partition the city into risk zones using KMeans on
    (latitude, longitude, risk_score).

    Adds `risk_zone` label (0 .. n_zones-1) sorted by average risk.
    """
    features = risk_df[["latitude", "longitude", "risk_score"]].copy()
    scaler = StandardScaler()
    X = scaler.fit_transform(features)

    km = KMeans(n_clusters=n_zones, random_state=42, n_init=10)
    risk_df["risk_zone"] = km.fit_predict(X)

    # Relabel zones by descending mean risk so zone-0 is the riskiest
    zone_risk = risk_df.groupby("risk_zone")["risk_score"].mean().sort_values(ascending=False)
    label_map = {old: new for new, old in enumerate(zone_risk.index)}
    risk_df["risk_zone"] = risk_df["risk_zone"].map(label_map)

    return risk_df


# ---------------------------------------------------------------------------
# Cluster summary
# ---------------------------------------------------------------------------
def blackspot_summary(risk_df: pd.DataFrame) -> pd.DataFrame:
    """
    Summarise each black-spot cluster with centroid, avg risk, and count.
    """
    clusters = risk_df[risk_df["blackspot_cluster"] >= 0]
    if clusters.empty:
        return pd.DataFrame()

    summary = clusters.groupby("blackspot_cluster").agg(
        num_locations=("location_id", "count"),
        avg_risk_score=("risk_score", "mean"),
        max_risk_score=("risk_score", "max"),
        centroid_lat=("latitude", "mean"),
        centroid_lon=("longitude", "mean"),
        total_accidents=("total_accidents", "sum"),
        total_casualties=("total_casualties", "sum"),
        zones=("zone", lambda x: ", ".join(x.unique())),
    ).reset_index()

    summary["avg_risk_score"] = summary["avg_risk_score"].round(2)
    summary = summary.sort_values("avg_risk_score", ascending=False).reset_index(drop=True)
    return summary
