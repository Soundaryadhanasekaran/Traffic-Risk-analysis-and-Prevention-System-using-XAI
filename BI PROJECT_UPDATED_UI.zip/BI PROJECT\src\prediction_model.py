"""
Machine Learning Prediction Models
====================================
Trains and evaluates models to predict:
    1. Accident probability for a given location in the next period
    2. Severity of a potential accident
    3. High-risk time windows

Models used:
    • Random Forest Classifier (primary)
    • Gradient Boosting (XGBoost wrapper via sklearn)
    • Logistic Regression (baseline)

Outputs: trained model objects, evaluation metrics, feature importances.
"""

import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, classification_report, confusion_matrix,
                              roc_auc_score)
from sklearn.preprocessing import LabelEncoder, StandardScaler

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Feature Engineering
# ---------------------------------------------------------------------------
def prepare_features(accidents: pd.DataFrame,
                     violations: pd.DataFrame,
                     locations: pd.DataFrame) -> pd.DataFrame:
    """
    Build a feature matrix at the location-month level for predicting
    whether an accident will occur in the next month.
    """
    acc = accidents.copy()
    acc["date"] = pd.to_datetime(acc["date"])
    acc["year_month"] = acc["date"].dt.to_period("M")

    vio = violations.copy()
    vio["date"] = pd.to_datetime(vio["date"])
    vio["year_month"] = vio["date"].dt.to_period("M")

    # Generate all location × month combinations
    all_months = pd.period_range(
        acc["year_month"].min(), acc["year_month"].max(), freq="M"
    )
    loc_ids = locations["location_id"].unique()
    idx = pd.MultiIndex.from_product([loc_ids, all_months],
                                      names=["location_id", "year_month"])
    df = pd.DataFrame(index=idx).reset_index()

    # --- Accident aggregates per location-month ---
    acc_agg = acc.groupby(["location_id", "year_month"]).agg(
        accident_count=("accident_id", "count"),
        total_casualties=("num_casualties", "sum"),
        avg_severity=("severity", lambda x: x.map(
            {"Minor": 1, "Moderate": 3, "Severe": 7, "Fatal": 15}).mean()),
        pct_night=("light_condition",
                   lambda x: x.isin(["Night-Lit", "Night-Unlit"]).mean()),
        pct_bad_weather=("weather",
                         lambda x: x.isin(["Rainy", "Foggy", "Stormy"]).mean()),
    ).reset_index()

    df = df.merge(acc_agg, on=["location_id", "year_month"], how="left")
    df = df.fillna(0)

    # --- Violation aggregates per location-month ---
    vio_agg = vio.groupby(["location_id", "year_month"]).agg(
        violation_count=("violation_id", "count"),
        pct_speeding=("violation_type", lambda x: (x == "Speeding").mean()),
        pct_drunk=("violation_type", lambda x: (x == "Drunk Driving").mean()),
    ).reset_index()
    df = df.merge(vio_agg, on=["location_id", "year_month"], how="left")
    df[["violation_count", "pct_speeding", "pct_drunk"]] = \
        df[["violation_count", "pct_speeding", "pct_drunk"]].fillna(0)

    # --- Location infrastructure features ---
    loc_feats = locations[["location_id", "speed_limit_kmph", "num_lanes",
                           "has_traffic_signal", "has_cctv", "has_street_light",
                           "near_school_hospital", "road_type", "zone"]].copy()
    le_road = LabelEncoder()
    le_zone = LabelEncoder()
    loc_feats["road_type_enc"] = le_road.fit_transform(loc_feats["road_type"])
    loc_feats["zone_enc"] = le_zone.fit_transform(loc_feats["zone"])
    loc_feats = loc_feats.drop(columns=["road_type", "zone"])
    for col in ["has_traffic_signal", "has_cctv", "has_street_light",
                "near_school_hospital"]:
        loc_feats[col] = loc_feats[col].astype(int)

    df = df.merge(loc_feats, on="location_id", how="left")

    # --- Temporal features ---
    df["month"] = df["year_month"].dt.month
    df["quarter"] = df["year_month"].dt.quarter

    # --- Lag features (previous month's accident count) ---
    df = df.sort_values(["location_id", "year_month"])
    df["prev_month_accidents"] = df.groupby("location_id")["accident_count"].shift(1).fillna(0)
    df["prev_month_violations"] = df.groupby("location_id")["violation_count"].shift(1).fillna(0)

    # --- Rolling 3-month average ---
    df["rolling_3m_accidents"] = df.groupby("location_id")["accident_count"] \
        .transform(lambda x: x.rolling(3, min_periods=1).mean())

    # --- Target: will there be an accident next month? ---
    df["target_accident"] = df.groupby("location_id")["accident_count"].shift(-1)
    df["target_accident"] = (df["target_accident"] > 0).astype(int)
    df = df.dropna(subset=["target_accident"])

    # --- Severity target ---
    next_severity = df.groupby("location_id")["avg_severity"].shift(-1)
    df["target_severity"] = pd.cut(
        next_severity.fillna(0),
        bins=[-0.1, 0, 3, 7, 100],
        labels=["None", "Low", "Medium", "High"]
    )

    return df


# ---------------------------------------------------------------------------
# Model Training
# ---------------------------------------------------------------------------
FEATURE_COLS = [
    "accident_count", "total_casualties", "avg_severity",
    "pct_night", "pct_bad_weather",
    "violation_count", "pct_speeding", "pct_drunk",
    "speed_limit_kmph", "num_lanes",
    "has_traffic_signal", "has_cctv", "has_street_light",
    "near_school_hospital", "road_type_enc", "zone_enc",
    "month", "quarter",
    "prev_month_accidents", "prev_month_violations",
    "rolling_3m_accidents",
]


def train_accident_predictor(df: pd.DataFrame, model_type: str = "rf"):
    """
    Train a binary classifier: will the location have an accident
    next month?

    Parameters
    ----------
    df : Feature matrix from `prepare_features`.
    model_type : 'rf' | 'gb' | 'lr'

    Returns
    -------
    model, metrics_dict, X_test, y_test, y_pred, feature_importances
    """
    X = df[FEATURE_COLS].values
    y = df["target_accident"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    if model_type == "rf":
        model = RandomForestClassifier(
            n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]
        feat_imp = dict(zip(FEATURE_COLS, model.feature_importances_))
    elif model_type == "gb":
        model = GradientBoostingClassifier(
            n_estimators=200, max_depth=6, learning_rate=0.1, random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]
        feat_imp = dict(zip(FEATURE_COLS, model.feature_importances_))
    else:  # logistic regression
        model = LogisticRegression(max_iter=1000, random_state=42)
        model.fit(X_train_s, y_train)
        y_pred = model.predict(X_test_s)
        y_proba = model.predict_proba(X_test_s)[:, 1]
        feat_imp = dict(zip(FEATURE_COLS, np.abs(model.coef_[0])))

    metrics = {
        "accuracy": round(accuracy_score(y_test, y_pred), 4),
        "precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
        "recall": round(recall_score(y_test, y_pred, zero_division=0), 4),
        "f1": round(f1_score(y_test, y_pred, zero_division=0), 4),
        "roc_auc": round(roc_auc_score(y_test, y_proba), 4),
    }

    # Cross-validation
    cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring="f1")
    metrics["cv_f1_mean"] = round(cv_scores.mean(), 4)
    metrics["cv_f1_std"] = round(cv_scores.std(), 4)

    report = classification_report(y_test, y_pred, output_dict=True)
    cm = confusion_matrix(y_test, y_pred)

    return {
        "model": model,
        "scaler": scaler,
        "metrics": metrics,
        "classification_report": report,
        "confusion_matrix": cm,
        "feature_importances": feat_imp,
        "X_test": X_test,
        "y_test": y_test,
        "y_pred": y_pred,
        "y_proba": y_proba,
        "feature_names": FEATURE_COLS,
    }


# ---------------------------------------------------------------------------
# Compare all models
# ---------------------------------------------------------------------------
def compare_models(df: pd.DataFrame) -> pd.DataFrame:
    """Train all 3 model types and return a comparison DataFrame."""
    results = {}
    for mt in ["rf", "gb", "lr"]:
        res = train_accident_predictor(df, model_type=mt)
        results[mt] = res["metrics"]

    comparison = pd.DataFrame(results).T
    comparison.index = ["Random Forest", "Gradient Boosting", "Logistic Regression"]
    comparison.index.name = "Model"
    return comparison


# ---------------------------------------------------------------------------
# High-risk period identification
# ---------------------------------------------------------------------------
def identify_high_risk_periods(accidents: pd.DataFrame) -> pd.DataFrame:
    """
    Identify the top high-risk time windows (hour × day combinations)
    based on historical accident frequency and severity.
    """
    acc = accidents.copy()
    acc["severity_score"] = acc["severity"].map(
        {"Minor": 1, "Moderate": 3, "Severe": 7, "Fatal": 15})

    periods = acc.groupby(["day_of_week", "hour"]).agg(
        accident_count=("accident_id", "count"),
        avg_severity=("severity_score", "mean"),
        total_casualties=("num_casualties", "sum"),
    ).reset_index()

    periods["period_risk"] = (
        periods["accident_count"] * 0.5 +
        periods["avg_severity"] * 0.3 +
        periods["total_casualties"] * 0.2
    )
    periods = periods.sort_values("period_risk", ascending=False).reset_index(drop=True)
    return periods
