"""
Streamlit Dashboard - Smart Traffic Accident Risk Prediction System
====================================================================
Interactive BI dashboard with multiple pages:
    1. Overview & KPI Cards
    2. Risk Map & Black Spots
    3. Trend Analysis
    4. Prediction & Explainability
    5. Prevention Recommendations
    6. Resource Allocation
"""

import sys
import os
import warnings
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_generator import generate_all_data
from src.risk_scoring import compute_risk_scores, compute_hourly_risk_matrix
from src.spatial_clustering import (detect_blackspots_dbscan,
                                     zone_clustering, blackspot_summary)
from src.prediction_model import (prepare_features, train_accident_predictor,
                                   compare_models, identify_high_risk_periods)
from src.explainability import (compute_shap_values, global_feature_importance,
                                 explain_location)
from src.prevention_engine import (generate_all_recommendations,
                                    generate_alerts,
                                    suggest_resource_allocation)

warnings.filterwarnings("ignore")

# ============================================================================
# Page Config & Custom Styling
# ============================================================================
st.set_page_config(
    page_title="Smart Traffic Risk Prediction System",
    page_icon="\U0001f6a6",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS styling for modern, attractive UI
def inject_custom_css():
    """Inject modern CSS styling for the dashboard."""
    custom_css = """
    <style>
    /* Main Theme Colors */
    :root {
        --primary: #7c3aed;
        --primary-light: #a855f7;
        --secondary: #06b6d4;
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --dark: #1f2937;
        --light: #f3f4f6;
    }
    
    /* Global Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    html, body, [data-testid="stAppViewContainer"] {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
        font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    /* Main Container */
    [data-testid="stAppViewContainer"] {
        color: #e0e7ff !important;
    }
    
    /* All Text Elements - Critical for Visibility */
    body, p, span, div, label, h1, h2, h3, h4, h5, h6 {
        color: #e0e7ff !important;
    }
    
    /* Main content area */
    [data-testid="stMain"] {
        color: #e0e7ff !important;
        background: transparent;
    }
    
    /* Markdown text */
    [data-testid="stMarkdownContainer"] {
        color: #e0e7ff !important;
    }
    
    [data-testid="stMarkdownContainer"] p {
        color: #e0e7ff !important;
    }
    
    /* Sidebar Styling - Professional Clean Look */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1a1631 0%, #2d1f4e 100%) !important;
        border-right: 3px solid #7c3aed !important;
    }
    
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"],
    [data-testid="stSidebar"] p,
    [data-testid="stSidebar"] span {
        color: #e0e7ff !important;
    }
    
    /* Side Navigation Label */
    [data-testid="stSidebar"] .stRadio > label {
        color: #a855f7 !important;
        font-weight: 700 !important;
        font-size: 1rem !important;
        margin-bottom: 15px !important;
    }
    
    /* Radio button options (Navigation items) */
    .stRadio > div {
        display: flex !important;
        flex-direction: column !important;
        gap: 8px !important;
    }
    
    .stRadio > div > label {
        background: linear-gradient(135deg, #312e81 0%, #3f3d80 100%) !important;
        padding: 12px 16px !important;
        border-radius: 8px !important;
        border-left: 4px solid #06b6d4 !important;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        color: #e0e7ff !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
        white-space: normal !important;
    }
    
    .stRadio > div > label:hover {
        border-left-color: #7c3aed !important;
        background: linear-gradient(135deg, #3f3d80 0%, #4f46e5 100%) !important;
        box-shadow: 0 6px 20px rgba(124, 58, 237, 0.3) !important;
        transform: translateX(4px);
    }
    
    .stRadio > div > label[aria-checked="true"] {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        border-left-color: #a855f7 !important;
        box-shadow: 0 8px 25px rgba(124, 58, 237, 0.5) !important;
        color: #ffffff !important;
    }
    
    /* Hide default radio styling */
    .stRadio > div > label > span:first-child {
        display: none !important;
    }
    
    /* Sidebar Title */
    [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2, [data-testid="stSidebar"] h3 {
        color: #a855f7 !important;
        font-weight: 700;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        margin: 20px 0 15px 0 !important;
    }
    
    /* Main Title Styling */
    h1 {
        background: linear-gradient(135deg, #a855f7 0%, #06b6d4 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: 800;
        font-size: 2.8rem !important;
        margin-bottom: 10px !important;
        text-shadow: 0 2px 8px rgba(124, 58, 237, 0.2);
    }
    
    h2 {
        color: #a855f7 !important;
        font-weight: 700;
        margin-top: 35px !important;
        margin-bottom: 20px !important;
        border-bottom: 2px solid #7c3aed;
        padding-bottom: 12px !important;
        font-size: 1.5rem !important;
    }
    
    h3 {
        color: #93c5fd !important;
        font-weight: 600;
        font-size: 1.2rem !important;
    }
    
    /* Metric Cards - Enhanced visibility */
    [data-testid="metric-container"] {
        background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%) !important;
        border-radius: 14px !important;
        padding: 24px 20px !important;
        border: 2px solid #4f46e5 !important;
        box-shadow: 0 10px 35px rgba(124, 58, 237, 0.25) !important;
        transition: all 0.3s ease;
        text-align: center;
        min-height: 140px;
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
    }
    
    [data-testid="metric-container"]:hover {
        background: linear-gradient(135deg, #312e81 0%, #4f46e5 100%) !important;
        border-color: #7c3aed;
        box-shadow: 0 15px 45px rgba(124, 58, 237, 0.35) !important;
        transform: translateY(-6px);
    }
    
    [data-testid="metric-container"] label,
    [data-testid="metric-container"] span:not([data-testid]) {
        color: #e0e7ff !important;
        font-size: 0.9rem !important;
        font-weight: 700 !important;
        letter-spacing: 0.5px;
        display: block !important;
        margin-bottom: 8px !important;
    }
    
    [data-testid="metric-container"] [data-testid="stMetricValue"] {
        color: #ffffff !important;
        font-size: 2.6rem !important;
        font-weight: 950 !important;
        line-height: 1.1 !important;
        margin: 10px 0 8px 0 !important;
        text-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
    }
    
    [data-testid="metric-container"] [data-testid="stMetricDelta"] {
        color: #10b981 !important;
        font-weight: 700 !important;
        font-size: 0.95rem !important;
        margin-top: 6px !important;
    }
    
    [data-testid="metric-container"] div:not([data-testid]) {
        color: #e0e7ff !important;
    }
    
    /* Data Frame Styling */
    [data-testid="dataframe"] {
        background: #1e293b !important;
        border-radius: 12px !important;
        border: 2px solid #4f46e5 !important;
        overflow: hidden;
        box-shadow: 0 10px 35px rgba(124, 58, 237, 0.2) !important;
    }
    
    [data-testid="dataframe"] th {
        background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%) !important;
        color: #ffffff !important;
        font-weight: 800 !important;
        border-color: #7c3aed !important;
        padding: 14px 12px !important;
        font-size: 0.98rem !important;
    }
    
    [data-testid="dataframe"] td {
        color: #e0e7ff !important;
        border-color: #334155 !important;
        padding: 14px 12px !important;
        font-size: 0.93rem !important;
        font-weight: 500 !important;
    }
    
    [data-testid="dataframe"] tr:hover {
        background: rgba(124, 58, 237, 0.2) !important;
    }
    
    /* DataFrame container */
    [data-testid="stDataFrame"] {
        color: #e0e7ff !important;
    }
    
    /* Expander Styling */
    [data-testid="stExpander"] {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
        border: 2px solid #7c3aed !important;
        border-radius: 12px !important;
    }
    
    [data-testid="stExpander"] summary {
        color: #a855f7 !important;
        font-weight: 700;
        padding: 12px !important;
    }
    
    /* Input Elements */
    input, select, textarea {
        background: #1e293b !important;
        color: #e0e7ff !important;
        border: 1px solid #4f46e5 !important;
        border-radius: 8px !important;
        padding: 10px 12px !important;
    }
    
    input:focus, select:focus, textarea:focus {
        border-color: #7c3aed !important;
        box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.2) !important;
    }
    
    /* Button Styling */
    button[data-testid="baseButton-primary"] {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        color: #ffffff !important;
        border: none !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        padding: 11px 22px !important;
        box-shadow: 0 4px 15px rgba(124, 58, 237, 0.3) !important;
        transition: all 0.3s ease;
    }
    
    button[data-testid="baseButton-primary"]:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(124, 58, 237, 0.4) !important;
    }
    
    /* Success/Info/Warning Messages */
    [data-testid="stSuccess"], [data-testid="stInfo"], [data-testid="stWarning"], [data-testid="stError"] {
        border-radius: 12px !important;
        border-left: 5px solid !important;
        padding: 18px !important;
        background: rgba(124, 58, 237, 0.1) !important;
        font-weight: 500;
    }
    
    [data-testid="stSuccess"] {
        border-left-color: #10b981 !important;
    }
    
    [data-testid="stInfo"] {
        border-left-color: #06b6d4 !important;
    }
    
    [data-testid="stWarning"] {
        border-left-color: #f59e0b !important;
    }
    
    [data-testid="stError"] {
        border-left-color: #ef4444 !important;
    }
    
    /* Slider Styling */
    .stSlider > div > div > div > input {
        accent-color: #7c3aed !important;
    }
    
    /* Markdown Links */
    a {
        color: #06b6d4 !important;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    a:hover {
        color: #a855f7 !important;
        text-decoration: underline;
    }
    
    /* Horizontal Line */
    hr {
        border: none !important;
        border-top: 2px solid !important;
        border-image: linear-gradient(90deg, #7c3aed 0%, #06b6d4 100%) 1 !important;
        margin: 35px 0 !important;
    }
    
    /* Spinner */
    [data-testid="stSpinner"] {
        color: #7c3aed !important;
    }
    
    /* Plotly Charts - Unified styling */
    .plotly-graph-div {
        background: linear-gradient(135deg, #0f172a 0%, #1a1a3e 100%) !important;
        border-radius: 14px !important;
        padding: 20px !important;
        border: 1px solid #4f46e5 !important;
        box-shadow: 0 10px 35px rgba(124, 58, 237, 0.15) !important;
    }
    
    .js-plotly-plot {
        background: transparent !important;
    }
    
    /* Main content container alignment */
    [data-testid="stMainBlockContainer"] {
        padding: 30px 40px !important;
    }
    
    /* Column alignment */
    [data-testid="column"] {
        padding: 10px 12px !important;
    }
    
    /* Scroll Bar */
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    
    ::-webkit-scrollbar-track {
        background: #1e293b;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(180deg, #7c3aed 0%, #06b6d4 100%);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(180deg, #a855f7 0%, #22d3ee 100%);
    }
    
    /* Main container and content alignment */
    [data-testid="stAppViewContainer"] > section {
        padding: 30px 40px !important;
    }
    
    /* Column spacing */
    [data-testid="column"] {
        gap: 20px !important;
    }
    
    /* Better spacing between elements */
    .stTabs [role="tablist"] {
        gap: 10px !important;
    }
    
    /* Improve slider visibility */
    .stSlider label {
        color: #e0e7ff !important;
        font-weight: 600 !important;
    }
    
    /* Multiselect styling */
    .stMultiSelect [data-testid="multiSelectSearchInput"] {
        color: #e0e7ff !important;
    }
    
    /* Number input styling */
    .stNumberInput input {
        color: #e0e7ff !important;
        font-weight: 600 !important;
    }
    
    /* Deploy Button and Toolbar - Make Visible */
    [data-testid="stToolbar"] {
        background: linear-gradient(90deg, rgba(30, 41, 59, 0.95) 0%, rgba(15, 23, 42, 0.95) 100%) !important;
    }
    
    [data-testid="stToolbar"] button {
        background: rgba(124, 58, 237, 0.2) !important;
        color: #e0e7ff !important;
        border: 1px solid #7c3aed !important;
        border-radius: 6px !important;
    }
    
    [data-testid="stToolbar"] button:hover {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        color: #ffffff !important;
        border-color: #a855f7 !important;
    }
    
    /* Deploy button and action buttons */
    button[kind="secondary"] {
        color: #e0e7ff !important;
        background: rgba(124, 58, 237, 0.2) !important;
        border: 1px solid #7c3aed !important;
    }
    
    button[kind="secondary"]:hover {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        color: #ffffff !important;
    }
    
    /* All buttons text visibility */
    button {
        color: #e0e7ff !important;
        font-weight: 600 !important;
    }
    
    button:hover,
    button:active {
        color: #ffffff !important;
    }
    
    /* Toolbar item text */
    [data-testid="stToolbar"] span,
    [data-testid="stToolbar"] p,
    [data-testid="stToolbar"] div {
        color: #e0e7ff !important;
    }
    
    /* Action buttons in toolbar */
    [data-testid="stToolbarActionButton"] {
        color: #e0e7ff !important;
    }
    
    [data-testid="stToolbarActionButton"] button {
        background: rgba(124, 58, 237, 0.2) !important;
        color: #e0e7ff !important;
        border: 1px solid #7c3aed !important;
        border-radius: 6px !important;
        padding: 8px 16px !important;
        font-weight: 600 !important;
    }
    
    [data-testid="stToolbarActionButton"] button:hover {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        color: #ffffff !important;
        border-color: #a855f7 !important;
    }
    """
    st.markdown(custom_css, unsafe_allow_html=True)

inject_custom_css()

# Navigation labels (using Unicode escapes to preserve emojis across encodings)
NAV_OVERVIEW = "\U0001f3e0 Overview"
NAV_RISK_MAP = "\U0001f5fa\ufe0f Risk Map"
NAV_TRENDS = "\U0001f4c8 Trend Analysis"
NAV_PREDICTION = "\U0001f916 Prediction & XAI"
NAV_PREVENTION = "\U0001f6e1\ufe0f Prevention"
NAV_RESOURCES = "\U0001f4cb Resource Allocation"
NAV_DATA_UPLOAD = "\U0001f4c4 Data Upload"


# ============================================================================
# Data Loading & Caching
# ============================================================================

# Initialize session state for file uploads
if "uploaded_data" not in st.session_state:
    st.session_state.uploaded_data = None
if "data_source" not in st.session_state:
    st.session_state.data_source = "sample"

def load_sample_data():
    """Load or generate sample data."""
    data_dir = os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "data")

    if not os.path.exists(os.path.join(data_dir, "accidents.csv")):
        datasets = generate_all_data(data_dir)
    else:
        datasets = {
            "locations": pd.read_csv(os.path.join(data_dir, "locations.csv")),
            "accidents": pd.read_csv(os.path.join(data_dir, "accidents.csv")),
            "violations": pd.read_csv(os.path.join(data_dir, "violations.csv")),
            "weather": pd.read_csv(os.path.join(data_dir, "weather.csv")),
        }
    return datasets


@st.cache_data
def load_data():
    """Load data based on source (sample or uploaded)."""
    if st.session_state.data_source == "uploaded" and st.session_state.uploaded_data:
        return st.session_state.uploaded_data
    else:
        return load_sample_data()


def handle_file_uploads(uploaded_files):
    """Handle uploaded CSV files and create datasets dictionary."""
    datasets = {}
    file_map = {}
    
    # Map uploaded files by name
    for uploaded_file in uploaded_files:
        file_map[uploaded_file.name.lower()] = uploaded_file
    
    try:
        # Load each required file
        if "accidents.csv" in file_map:
            datasets["accidents"] = pd.read_csv(file_map["accidents.csv"])
        else:
            st.error("❌ Missing 'accidents.csv' file")
            return None
            
        if "violations.csv" in file_map:
            datasets["violations"] = pd.read_csv(file_map["violations.csv"])
        else:
            st.error("❌ Missing 'violations.csv' file")
            return None
            
        if "locations.csv" in file_map:
            datasets["locations"] = pd.read_csv(file_map["locations.csv"])
        else:
            st.error("❌ Missing 'locations.csv' file")
            return None
        
        # Weather is optional - generate if not provided
        if "weather.csv" in file_map:
            datasets["weather"] = pd.read_csv(file_map["weather.csv"])
        else:
            st.warning("⚠️ 'weather.csv' not found. Generating default weather data...")
            # Generate default weather data if not provided
            from src.data_generator import generate_weather
            datasets["weather"] = generate_weather()
        
        # Validate basic structure
        required_accident_cols = ["location_id", "date", "hour"]
        required_violation_cols = ["location_id", "date"]
        required_location_cols = ["location_id", "latitude", "longitude"]
        
        for col in required_accident_cols:
            if col not in datasets["accidents"].columns:
                st.error(f"❌ accidents.csv missing required column: '{col}'")
                return None
                
        for col in required_violation_cols:
            if col not in datasets["violations"].columns:
                st.error(f"❌ violations.csv missing required column: '{col}'")
                return None
                
        for col in required_location_cols:
            if col not in datasets["locations"].columns:
                st.error(f"❌ locations.csv missing required column: '{col}'")
                return None
        
        return datasets
        
    except Exception as e:
        st.error(f"❌ Error processing files: {str(e)}")
        return None


@st.cache_data
def compute_risk_data(locations, accidents, violations):
    risk_df = compute_risk_scores(accidents, violations, locations)
    risk_df = detect_blackspots_dbscan(risk_df)
    risk_df = zone_clustering(risk_df)
    return risk_df


@st.cache_data
def train_model(accidents, violations, locations):
    features_df = prepare_features(accidents, violations, locations)
    result_rf = train_accident_predictor(features_df, model_type="rf")
    result_gb = train_accident_predictor(features_df, model_type="gb")
    result_lr = train_accident_predictor(features_df, model_type="lr")
    comparison = compare_models(features_df)
    return features_df, result_rf, result_gb, result_lr, comparison


# ============================================================================
# Sidebar
# ============================================================================
def render_sidebar():
    """Render clean, professional sidebar with navigation."""
    # Logo/Header
    st.sidebar.markdown("---")
    col1, col2 = st.sidebar.columns([1, 3])
    with col1:
        st.sidebar.markdown("🚦")
    with col2:
        st.sidebar.markdown("### Risk BI")
    
    st.sidebar.markdown("---")
    
    # Navigation Menu
    st.sidebar.markdown("<p style='color: #a855f7; font-weight: 700; font-size: 0.95rem; margin-bottom: 12px;'>📍 NAVIGATION</p>", unsafe_allow_html=True)
    
    page = st.sidebar.radio(
        "Select Page",
        [NAV_DATA_UPLOAD, NAV_OVERVIEW, NAV_RISK_MAP, NAV_TRENDS,
         NAV_PREDICTION, NAV_PREVENTION, NAV_RESOURCES],
        label_visibility="collapsed"
    )

    st.sidebar.markdown("---")
    
    # System Info
    st.sidebar.markdown("<p style='color: #a855f7; font-weight: 700; font-size: 0.95rem; margin-bottom: 12px;'>📊 SYSTEM INFO</p>", unsafe_allow_html=True)
    st.sidebar.markdown("""
    <div style='color: #e0e7ff; font-size: 0.85rem; line-height: 1.8;'>
    <strong>Smart Traffic Risk</strong><br>
    Prediction & Prevention System<br><br>
    <em style='color: #93c5fd;'>Advanced Analytics Engine</em>
    </div>
    """, unsafe_allow_html=True)
    
    st.sidebar.markdown("---")
    
    # Features List
    st.sidebar.markdown("<p style='color: #a855f7; font-weight: 700; font-size: 0.95rem; margin-bottom: 12px;'>✨ FEATURES</p>", unsafe_allow_html=True)
    st.sidebar.markdown("""
    <div style='color: #e0e7ff; font-size: 0.85rem; line-height: 2.2;'>
    ✅ Real-time Risk Analysis<br>
    🗺️ Geospatial Mapping<br>
    🤖 AI Predictions<br>
    📋 Prevention Plans<br>
    🎯 Resource Optimization
    </div>
    """, unsafe_allow_html=True)
    
    return page


# ============================================================================
# PAGE 1: Overview & KPIs
# ============================================================================
def page_overview(datasets, risk_df):
    st.title("🏠 Smart Traffic Risk Dashboard")
    st.markdown("**Real-time Traffic Accident Risk Analytics & Prevention System**")
    st.markdown("---")

    accidents = datasets["accidents"]
    violations = datasets["violations"]

    # KPI Cards with enhanced styling
    st.markdown("### 📊 Key Performance Indicators")
    col1, col2, col3, col4, col5 = st.columns(5, gap="medium")
    
    with col1:
        col1.metric("🚗 Total Accidents", f"{len(accidents):,}", delta="+12%", delta_color="inverse")
    with col2:
        col2.metric("⚠️ Violations", f"{len(violations):,}", delta="+8%", delta_color="inverse")
    with col3:
        col3.metric("👥 Casualties", f"{accidents['num_casualties'].sum():,}", delta="-3%", delta_color="normal")
    with col4:
        col4.metric("💀 Fatalities", f"{accidents['num_fatalities'].sum():,}", delta="-5%", delta_color="normal")
    
    critical_count = (risk_df["risk_level"] == "Critical").sum()
    with col5:
        col5.metric("🔴 Critical Zones", f"{critical_count}", delta=f"{critical_count} high risk", delta_color="inverse")

    st.markdown("---")

    # Row 2: Charts with enhanced styling
    st.markdown("### 📈 Analytics Overview")
    col_a, col_b = st.columns(2, gap="large")

    with col_a:
        st.subheader("Accident Severity Distribution")
        sev_counts = accidents["severity"].value_counts()
        fig = px.pie(values=sev_counts.values, names=sev_counts.index,
                     color_discrete_sequence=['#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6'],
                     hole=0.4)
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=12, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=True,
            legend=dict(font=dict(color='#e0e7ff'))
        )
        fig.update_traces(textposition='inside', textinfo='percent+label', textfont=dict(size=11, color='white'))
        st.plotly_chart(fig, use_container_width=True, config={'responsive': True, 'displayModeBar': False})

    with col_b:
        st.subheader("Top 10 Accident Causes")
        cause_counts = accidents["cause"].value_counts().head(10)
        fig = px.bar(x=cause_counts.values, y=cause_counts.index,
                     orientation="h",
                     color=cause_counts.values,
                     color_continuous_scale=['#4f46e5', '#7c3aed', '#a855f7', '#06b6d4'],
                     labels={"x": "Number of Accidents", "y": "Cause"})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=11, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=False,
            coloraxis_showscale=False,
            margin=dict(l=150, r=50, t=30, b=50),
            xaxis=dict(showgrid=True, gridwidth=1, gridcolor='rgba(124, 58, 237, 0.1)'),
        )
        fig.update_traces(text=[f'{v:,.0f}' for v in cause_counts.values],
                         textposition='outside', textfont=dict(size=10, color='#a855f7'))
        st.plotly_chart(fig, use_container_width=True, config={'responsive': True, 'displayModeBar': False})

    # Row 3: Trends and Risk Distribution
    st.markdown("---")
    col_c, col_d = st.columns(2, gap="large")

    with col_c:
        st.subheader("Monthly Accident Trend")
        accidents_copy = accidents.copy()
        accidents_copy["date"] = pd.to_datetime(accidents_copy["date"])
        monthly = accidents_copy.groupby(accidents_copy["date"].dt.to_period("M")).size()
        monthly.index = monthly.index.to_timestamp()
        
        fig = px.line(x=monthly.index, y=monthly.values,
                      labels={"x": "Month", "y": "Number of Accidents"},
                      markers=True)
        fig.add_vrect(x0=monthly.index.min(), x1=monthly.index.max(), 
                      fillcolor='#7c3aed', opacity=0.1, layer='below', line_width=0)
        fig.update_traces(line=dict(color='#06b6d4', width=3),
                          marker=dict(size=10, color='#a855f7', symbol='circle', 
                                    line=dict(color='#06b6d4', width=2)))
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=11, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            hovermode='x unified',
            margin=dict(l=50, r=50, t=30, b=50),
            xaxis=dict(showgrid=True, gridwidth=1, gridcolor='rgba(124, 58, 237, 0.1)'),
            yaxis=dict(showgrid=True, gridwidth=1, gridcolor='rgba(124, 58, 237, 0.1)'),
        )
        st.plotly_chart(fig, use_container_width=True, config={'responsive': True, 'displayModeBar': False})

    with col_d:
        st.subheader("Risk Level Distribution")
        risk_counts = risk_df["risk_level"].value_counts()
        colors_map = {"Low": "#10b981", "Medium": "#f59e0b",
                      "High": "#ef4444", "Critical": "#8b5cf6"}
        
        fig = px.bar(x=risk_counts.index, y=risk_counts.values,
                     color=risk_counts.index,
                     color_discrete_map=colors_map,
                     labels={"x": "Risk Level", "y": "Number of Zones"},
                     category_orders={"x": ["Low", "Medium", "High", "Critical"]})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=11, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            showlegend=False,
            margin=dict(l=50, r=50, t=30, b=50),
            xaxis=dict(showgrid=False),
            yaxis=dict(showgrid=True, gridwidth=1, gridcolor='rgba(124, 58, 237, 0.1)'),
        )
        fig.update_traces(text=[f'{v:,.0f}' for v in risk_counts.values],
                         textposition='outside', textfont=dict(size=11, color='white', weight='bold'))
        st.plotly_chart(fig, use_container_width=True, config={'responsive': True, 'displayModeBar': False})

    # Top 10 riskiest locations table
    st.markdown("---")
    st.subheader("🔴 Top 10 Highest Risk Locations")
    top_10 = risk_df.head(10)[["location_id", "zone", "road_type",
                                "risk_score", "risk_level",
                                "total_accidents", "total_violations",
                                "total_casualties", "total_fatalities"]].copy()
    top_10["risk_score"] = top_10["risk_score"].round(2)
    st.dataframe(top_10, use_container_width=True, hide_index=True)


# ============================================================================
# PAGE 2: Risk Map & Black Spots
# ============================================================================
def page_risk_map(risk_df):
    st.title("\U0001f5fa Risk Map & Black Spot Detection")
    st.markdown("**Spatial Analysis of High-Risk Accident Zones**")
    st.markdown("---")

    col1, col2 = st.columns([3, 1])

    with col1:
        st.subheader("Geospatial Risk Heatmap")
        risk_df_copy = risk_df.copy()

        # Use consistent purple-to-red gradient for map
        fig = px.scatter_mapbox(
            risk_df_copy, lat="latitude", lon="longitude",
            color="risk_score",
            color_continuous_scale=[[0, '#312e81'], [0.3, '#7c3aed'], [0.6, '#a855f7'], [1, '#ef4444']],
            size="risk_score",
            size_max=25,
            hover_name="location_id",
            hover_data={"risk_score": ":.2f", "zone": True, "total_accidents": True, "latitude": False, "longitude": False},
            mapbox_style="carto-positron",
            zoom=10,
            height=650,
        )
        fig.update_layout(
            margin=dict(l=0, r=0, t=0, b=0),
            font=dict(color='#e0e7ff', size=10, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            coloraxis_colorbar=dict(
                title="Risk Score",
                thickness=15,
                len=0.7,
                x=1.02,
                tickfont=dict(color='#e0e7ff')
            )
        )
        st.plotly_chart(fig, use_container_width=True, config={'responsive': True, 'displayModeBar': False})

    with col2:
        st.subheader("Risk Summary")
        risk_summary = {
            "Critical": (risk_df["risk_level"] == "Critical").sum(),
            "High": (risk_df["risk_level"] == "High").sum(),
            "Medium": (risk_df["risk_level"] == "Medium").sum(),
            "Low": (risk_df["risk_level"] == "Low").sum(),
        }
        
        for level in ["Critical", "High", "Medium", "Low"]:
            col2.metric(f"⚠️ {level}", risk_summary[level], label_visibility="visible")

    # Black Spot Clusters
    st.markdown("---")
    st.subheader("⚫ Detected Black Spot Clusters")
    bs_summary = blackspot_summary(risk_df)
    if not bs_summary.empty:
        st.dataframe(bs_summary, use_container_width=True, hide_index=True)

        fig2 = px.scatter_mapbox(
            bs_summary, lat="centroid_lat", lon="centroid_lon",
            size="num_locations",
            color="avg_risk_score",
            color_continuous_scale=[[0, '#1e1b4b'], [0.5, '#7c3aed'], [1, '#ef4444']],
            hover_data={"num_locations": True, "total_accidents": True, "zones": True, 
                       "centroid_lat": False, "centroid_lon": False},
            mapbox_style="carto-positron",
            zoom=10, height=500,
        )
        fig2.update_layout(
            margin=dict(l=0, r=0, t=40, b=0),
            title="Black Spot Cluster Centroids",
            font=dict(color='#e0e7ff', size=10, family="Arial"),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            coloraxis_colorbar=dict(
                title="Avg Risk",
                thickness=15,
                len=0.6,
                tickfont=dict(color='#e0e7ff')
            )
        )
        st.plotly_chart(fig2, use_container_width=True, config={'responsive': True, 'displayModeBar': False})
    else:
        st.info("ℹ️ No black spot clusters detected with current parameters.")

    # Zone-level risk heatmap
    st.markdown("---")
    st.subheader("📊 Risk Distribution by Zone & Road Type")
    zone_road = risk_df.groupby(["zone", "road_type"])["risk_score"].mean().reset_index()
    fig3 = px.density_heatmap(
        zone_road, x="road_type", y="zone", z="risk_score",
        color_continuous_scale=[[0, '#312e81'], [0.5, '#7c3aed'], [1, '#ef4444']],
        labels={"risk_score": "Avg Risk Score"},
        height=450,
    )
    fig3.update_layout(
        font=dict(color='#e0e7ff', size=11, family="Arial"),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        coloraxis_colorbar=dict(
            title="Risk Score",
            thickness=15,
            len=0.8,
            tickfont=dict(color='#e0e7ff')
        )
    )
    st.plotly_chart(fig3, use_container_width=True, config={'responsive': True, 'displayModeBar': False})


# ============================================================================
# PAGE 3: Trend Analysis
# ============================================================================
def page_trends(datasets):
    st.title("📈 Trend Analysis & Patterns")
    st.markdown("**Temporal and Seasonal Analysis of Traffic Accidents**")
    st.markdown("---")

    accidents = datasets["accidents"].copy()
    violations = datasets["violations"].copy()
    accidents["date"] = pd.to_datetime(accidents["date"])
    violations["date"] = pd.to_datetime(violations["date"])

    # Time-of-day analysis
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("⏰ Accidents by Hour of Day")
        hourly = accidents.groupby("hour").size().reset_index(name="count")
        fig = px.bar(hourly, x="hour", y="count",
                     color="count", color_continuous_scale=['#7c3aed', '#06b6d4'],
                     labels={"hour": "Hour of Day", "count": "Number of Accidents"})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            coloraxis_showscale=False
        )
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("⚖️ Violations by Type")
        vio_type = violations["violation_type"].value_counts()
        colors_qual = ['#7c3aed', '#06b6d4', '#a855f7', '#22d3ee', '#8b5cf6']
        fig = px.pie(values=vio_type.values, names=vio_type.index,
                     hole=0.3, color_discrete_sequence=colors_qual)
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    # Hourly risk heatmap
    st.markdown("---")
    st.subheader("\U0001f525 Accident Intensity Heatmap: Hour × Day of Week")
    matrix = compute_hourly_risk_matrix(accidents)
    fig = px.imshow(
        matrix, color_continuous_scale="Purples",
        labels=dict(x="Hour of Day", y="Day of Week", color="Accidents"),
        aspect="auto", height=400,
    )
    fig.update_layout(
        font=dict(color='#e0e7ff', size=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    st.plotly_chart(fig, use_container_width=True)

    # Seasonality
    st.markdown("---")
    col3, col4 = st.columns(2)

    with col3:
        st.subheader("📅 Seasonal Pattern (Monthly)")
        monthly_sev = accidents.groupby(["month", "severity"]).size().reset_index(name="count")
        fig = px.bar(monthly_sev, x="month", y="count", color="severity",
                     barmode="stack", color_discrete_map={
                         "Minor": "#10b981", "Moderate": "#f59e0b",
                         "Severe": "#ef4444", "Fatal": "#8b5cf6"},
                     labels={"month": "Month", "count": "Accidents"},
                     category_orders={"month": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                                                 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    with col4:
        st.subheader("🌦️ Weather Impact on Accidents")
        weather_sev = accidents.groupby("weather").agg(
            count=("accident_id", "count"),
            avg_casualties=("num_casualties", "mean"),
        ).reset_index()
        fig = px.bar(weather_sev, x="weather", y="count",
                     color="avg_casualties", color_continuous_scale=['#7c3aed', '#ef4444'],
                     labels={"count": "Accidents", "avg_casualties": "Avg Casualties"})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    # Vehicle type analysis
    st.markdown("---")
    st.subheader("\U0001f697 Accident Distribution by Vehicle Type")
    veh_sev = accidents.groupby(["primary_vehicle", "severity"]).size().reset_index(name="count")
    fig = px.bar(veh_sev, x="primary_vehicle", y="count", color="severity",
                 barmode="group",
                 color_discrete_map={
                     "Minor": "#10b981", "Moderate": "#f59e0b",
                     "Severe": "#ef4444", "Fatal": "#8b5cf6"})
    fig.update_layout(
        height=420,
        font=dict(color='#e0e7ff', size=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    st.plotly_chart(fig, use_container_width=True)


# ============================================================================
# PAGE 4: Prediction & Explainability
# ============================================================================
def page_prediction(features_df, result_rf, result_gb, result_lr, comparison):
    st.title("🤖 AI-Powered Prediction & Explainability")
    st.markdown("**Machine Learning Models with SHAP Interpretability**")
    st.markdown("---")

    # Model comparison
    st.subheader("📊 Model Performance Comparison")
    st.dataframe(comparison, use_container_width=True)

    # Metrics visualization
    st.markdown("---")
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Performance Metrics by Model")
        metric_names = ["accuracy", "precision", "recall", "f1", "roc_auc"]
        fig = go.Figure()
        colors_bar = ['#7c3aed', '#06b6d4', '#f59e0b']
        for idx, (model_name, result) in enumerate([("Random Forest", result_rf),
                                                     ("Gradient Boosting", result_gb),
                                                     ("Logistic Regression", result_lr)]):
            vals = [result["metrics"][m] for m in metric_names]
            fig.add_trace(go.Bar(name=model_name, x=metric_names, y=vals, 
                                marker_color=colors_bar[idx]))
        fig.update_layout(
            barmode="group", 
            title="",
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            xaxis_title="Metrics",
            yaxis_title="Score"
        )
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        # Confusion matrix for best model
        st.subheader("Confusion Matrix (Random Forest)")
        cm = result_rf["confusion_matrix"]
        fig = px.imshow(cm, text_auto=True, color_continuous_scale="Purples",
                        labels=dict(x="Predicted", y="Actual"),
                        x=["No Accident", "Accident"],
                        y=["No Accident", "Accident"])
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=11),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    # Feature Importance
    st.markdown("---")
    st.subheader("\U0001f50d Feature Importance (Random Forest)")
    imp = result_rf["feature_importances"]
    imp_df = pd.DataFrame({
        "Feature": list(imp.keys()),
        "Importance": list(imp.values()),
    }).sort_values("Importance", ascending=True)

    fig = px.bar(imp_df, x="Importance", y="Feature", orientation="h",
                 color="Importance", color_continuous_scale=['#7c3aed', '#06b6d4'],
                 height=450)
    fig.update_layout(
        title="",
        font=dict(color='#e0e7ff', size=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        coloraxis_showscale=False
    )
    st.plotly_chart(fig, use_container_width=True)

    # SHAP Explanations
    st.markdown("---")
    st.subheader("\U0001f9e0 Explainable AI - SHAP Analysis")
    try:
        shap_result = compute_shap_values(result_rf)
        imp_shap = global_feature_importance(shap_result)

        if "mean_abs_shap" in imp_shap.columns:
            fig = px.bar(imp_shap, x="mean_abs_shap", y="feature",
                         orientation="h", color="mean_abs_shap",
                         color_continuous_scale=['#7c3aed', '#ef4444'],
                         labels={"mean_abs_shap": "Mean |SHAP Value|", "feature": "Feature"},
                         height=450)
            fig.update_layout(
                title="SHAP Feature Importance",
                font=dict(color='#e0e7ff', size=10),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)'
            )
            st.plotly_chart(fig, use_container_width=True)

            # Single prediction explanation
            st.markdown("---")
            st.subheader("\U0001f4dd Individual Prediction Explanation")
            idx = st.slider("Select sample index", 0,
                            min(len(result_rf["X_test"]) - 1, 500), 0)
            exp_df = explain_location(shap_result, idx)
            if "info" not in exp_df.columns:
                fig = px.bar(exp_df.head(10), x="shap_value", y="feature",
                             orientation="h", color="direction",
                             color_discrete_map={
                                 "\u2191 Increases Risk": "#ef4444",
                                 "\u2193 Decreases Risk": "#10b981"},
                             height=380,
                             title=f"SHAP Explanation for Sample #{idx}")
                fig.update_layout(
                    font=dict(color='#e0e7ff', size=10),
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)'
                )
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.dataframe(imp_shap, use_container_width=True)
    except Exception as e:
        st.warning(f"⚠️ SHAP analysis unavailable: {e}")
        st.info("Install SHAP with: `pip install shap`")

    # High-risk periods
    st.markdown("---")
    st.subheader("\u23f0 High-Risk Time Periods")
    high_risk_periods = identify_high_risk_periods(
        pd.read_csv(os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "data", "accidents.csv")))
    st.dataframe(high_risk_periods.head(15), use_container_width=True,
                 hide_index=True)


# ============================================================================
# PAGE 5: Prevention Recommendations
# ============================================================================
def page_prevention(risk_df):
    st.title("🛡️ Prevention Recommendations & Alerts")
    st.markdown("**Actionable Insights & Risk Mitigation Strategies**")
    st.markdown("---")

    # Alerts
    st.subheader("\U0001f6a8 Active Alerts & Warnings")
    alerts = generate_alerts(risk_df)
    if alerts:
        alerts_df = pd.DataFrame(alerts)
        critical_alerts = alerts_df[alerts_df["alert_level"].str.contains("CRITICAL")]
        high_alerts = alerts_df[alerts_df["alert_level"].str.contains("HIGH")]

        col1, col2, col3 = st.columns(3)
        col1.metric("\U0001f534 Critical Alerts", len(critical_alerts), delta="Urgent")
        col2.metric("\U0001f7e0 High Alerts", len(high_alerts), delta="Important")
        col3.metric("📍 Total Locations", len(alerts_df))

        with st.expander("📋 View All Alerts", expanded=True):
            st.dataframe(alerts_df[["alert_level", "location_id", "zone",
                                     "risk_score", "message"]],
                         use_container_width=True, hide_index=True)
    else:
        st.success("✅ No active alerts at this time. System is operating normally.")

    # Recommendations
    st.markdown("---")
    st.subheader("\U0001f4cb Prevention Recommendations")
    recs_df = generate_all_recommendations(risk_df)

    if not recs_df.empty:
        # Filter controls
        col1, col2, col3 = st.columns(3)
        with col1:
            pri_filter = st.multiselect("🎯 Priority Level", recs_df["priority"].unique(),
                                         default=["Critical", "High"])
        with col2:
            cat_filter = st.multiselect("📂 Category", recs_df["category"].unique(),
                                         default=recs_df["category"].unique())
        with col3:
            risk_filter = st.slider("📊 Min Risk Score", 0, 100, 50)

        filtered = recs_df[
            (recs_df["priority"].isin(pri_filter)) &
            (recs_df["category"].isin(cat_filter)) &
            (recs_df["risk_score"] >= risk_filter)
        ]
        
        st.write(f"**Showing {len(filtered)} recommendations**")
        st.dataframe(filtered[["location_id", "risk_score", "risk_level",
                                "priority", "category", "recommendation"]],
                     use_container_width=True, hide_index=True)

        # Summary by category
        st.markdown("---")
        st.subheader("Recommendations Distribution")
        cat_summary = filtered.groupby("category").size().reset_index(name="count")
        fig = px.pie(cat_summary, values="count", names="category",
                     color_discrete_sequence=['#7c3aed', '#06b6d4', '#a855f7', '#22d3ee', '#8b5cf6'],
                     hole=0.3)
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=11),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)
# ============================================================================
# PAGE 6: Resource Allocation
# ============================================================================
def page_resources(risk_df):
    st.title("📋 Resource Allocation Strategy")
    st.markdown("**Optimize Emergency Response Resource Distribution**")
    st.markdown("---")

    col1, col2 = st.columns(2)
    with col1:
        patrol_units = st.number_input("🚔 Total Patrol Units Available", 10, 200, 50)
    with col2:
        ambulances = st.number_input("🚑 Total Ambulances Available", 5, 100, 20)

    allocation = suggest_resource_allocation(risk_df, patrol_units, ambulances)

    st.subheader("📍 Suggested Zone-wise Allocation")
    st.dataframe(allocation, use_container_width=True, hide_index=True)

    # Visualizations
    st.markdown("---")
    col_a, col_b = st.columns(2)

    with col_a:
        fig = px.bar(allocation, x="zone", y="suggested_patrols",
                     color="avg_risk",
                     color_continuous_scale=['#7c3aed', '#ef4444'],
                     title="Patrol Units Distribution per Zone",
                     labels={"suggested_patrols": "Patrol Units"})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    with col_b:
        fig = px.bar(allocation, x="zone", y="suggested_ambulances",
                     color="avg_risk",
                     color_continuous_scale=['#7c3aed', '#ef4444'],
                     title="Ambulances Distribution per Zone",
                     labels={"suggested_ambulances": "Ambulances"})
        fig.update_layout(
            height=380,
            font=dict(color='#e0e7ff', size=10),
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'
        )
        st.plotly_chart(fig, use_container_width=True)

    # Zone risk comparison
    st.markdown("---")
    st.subheader("⚖️ Zone Risk Comparison Analysis")
    fig = px.scatter(allocation, x="avg_risk", y="max_risk",
                     size="total_accidents", color="zone",
                     hover_data=["num_locations"],
                     title="Average vs Maximum Risk Score by Zone",
                     labels={"avg_risk": "Average Risk Score",
                             "max_risk": "Maximum Risk Score"})
    fig.update_layout(
        height=450,
        font=dict(color='#e0e7ff', size=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    fig.update_traces(marker=dict(line=dict(width=2, color='#7c3aed')))
    st.plotly_chart(fig, use_container_width=True)


# ============================================================================
# Main App
# ============================================================================
# ============================================================================
# PAGE 0: Data Upload & Management (REDESIGNED)
# ============================================================================
def page_data_upload():
    st.title("📤 Data Upload Center")
    st.markdown("**Choose your data source and start analyzing**")
    st.markdown("---")

    # ============================================================================
    # STEP 1: CHOOSE DATA SOURCE (Top Priority)
    # ============================================================================
    st.markdown("### ⬇️ Step 1: Choose Your Data Source")
    
    tab1, tab2 = st.tabs(["🎯 Quick Start (Recommended)", "📁 Upload Custom Data"])
    
    # ============================================================================
    # TAB 1: SAMPLE DATA (QUICK START)
    # ============================================================================
    with tab1:
        st.markdown("""
        <div style='padding: 20px; background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%); 
                    border-radius: 12px; border: 2px solid #10b981; margin-bottom: 20px;'>
            <h3 style='color: #10b981; margin-top: 0;'>✅ Use Pre-Generated Sample Data</h3>
            <p style='color: #e0e7ff; margin: 10px 0;'>
                <strong>Perfect for:</strong> Testing the dashboard, learning features, seeing examples
            </p>
            <ul style='color: #a855f7;'>
                <li>✓ 120 traffic intersections</li>
                <li>✓ 5,000+ accident records</li>
                <li>✓ 15,000+ traffic violations</li>
                <li>✓ Ready to analyze immediately</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            if st.button("▶️ USE SAMPLE DATA", use_container_width=True, type="primary", key="btn_sample"):
                st.session_state.data_source = "sample"
                st.session_state.uploaded_data = None
                st.success("✅ Sample dataset activated! You can now go to **🏠 Overview** page.")
                st.balloons()

    # ============================================================================
    # TAB 2: UPLOAD CUSTOM DATA
    # ============================================================================
    with tab2:
        st.markdown("""
        <div style='padding: 20px; background: linear-gradient(135deg, #312e81 0%, #3f3d80 100%); 
                    border-radius: 12px; border: 2px solid #06b6d4; margin-bottom: 20px;'>
            <h3 style='color: #06b6d4; margin-top: 0;'>📁 Upload Your Own Dataset</h3>
            <p style='color: #e0e7ff; margin: 10px 0;'>
                <strong>Perfect for:</strong> Analyzing your real traffic data
            </p>
            <p style='color: #f59e0b; font-weight: bold;'>You need 3 CSV files:</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Visual guide for required files
        col_acc, col_vio, col_loc = st.columns(3)
        
        with col_acc:
            st.markdown("""
            <div style='background: #1e293b; padding: 15px; border-radius: 8px; border-left: 4px solid #ef4444;'>
                <h4 style='color: #ef4444; margin: 0;'>1️⃣ accidents.csv</h4>
                <p style='color: #e0e7ff; font-size: 0.9em; margin: 10px 0;'>Accident records with date, location, severity</p>
                <code style='color: #a855f7; font-size: 0.85em;'>Required: location_id, date, hour</code>
            </div>
            """, unsafe_allow_html=True)
        
        with col_vio:
            st.markdown("""
            <div style='background: #1e293b; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b;'>
                <h4 style='color: #f59e0b; margin: 0;'>2️⃣ violations.csv</h4>
                <p style='color: #e0e7ff; font-size: 0.9em; margin: 10px 0;'>Traffic violations with fines, types</p>
                <code style='color: #a855f7; font-size: 0.85em;'>Required: location_id, date</code>
            </div>
            """, unsafe_allow_html=True)
        
        with col_loc:
            st.markdown("""
            <div style='background: #1e293b; padding: 15px; border-radius: 8px; border-left: 4px solid #06b6d4;'>
                <h4 style='color: #06b6d4; margin: 0;'>3️⃣ locations.csv</h4>
                <p style='color: #e0e7ff; font-size: 0.9em; margin: 10px 0;'>Intersections with GPS, speed limits</p>
                <code style='color: #a855f7; font-size: 0.85em;'>Required: location_id, latitude, longitude</code>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("---")
        
        # FILE UPLOADER (Main interaction)
        st.markdown("#### 📤 Upload Your Files Here")
        st.info("💡 **Tip:** Drag and drop or click to select files. You need all 3 CSV files to proceed.")
        
        uploaded_files = st.file_uploader(
            "Select CSV files",
            type="csv",
            accept_multiple_files=True,
            key="file_uploader",
            label_visibility="collapsed"
        )
        
        # ============================================================================
        # File Validation & Processing
        # ============================================================================
        if uploaded_files:
            st.markdown("---")
            
            # Show uploaded files list
            st.markdown("#### ✅ Files Received")
            for i, file in enumerate(uploaded_files, 1):
                st.write(f"{i}. **{file.name}** • {file.size:,} bytes")
            
            # Validate and process button
            st.markdown("---")
            col_btn1, col_btn2, col_btn3 = st.columns([1, 2, 1])
            with col_btn2:
                process_btn = st.button("✓ VALIDATE & UPLOAD DATA", use_container_width=True, type="primary")
            
            if process_btn:
                with st.spinner("🔍 Validating files..."):
                    datasets = handle_file_uploads(uploaded_files)
                    
                    if datasets:
                        st.session_state.uploaded_data = datasets
                        st.session_state.data_source = "uploaded"
                        
                        st.markdown("---")
                        st.success("✅ Success! Your data has been validated and loaded.")
                        
                        # ============================================================================
                        # Show Data Summary
                        # ============================================================================
                        st.markdown("#### 📊 Data Summary")
                        
                        metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
                        with metric_col1:
                            st.metric("📍 Locations", f"{len(datasets['locations']):,}")
                        with metric_col2:
                            st.metric("🚗 Accidents", f"{len(datasets['accidents']):,}")
                        with metric_col3:
                            st.metric("⚠️ Violations", f"{len(datasets['violations']):,}")
                        with metric_col4:
                            # Date range
                            try:
                                date_range = pd.to_datetime(datasets['accidents']['date']).dt.year.nunique()
                                st.metric("📅 Years", f"{date_range}")
                            except:
                                st.metric("📅 Years", "N/A")
                        
                        # ============================================================================
                        # Data Preview
                        # ============================================================================
                        st.markdown("---")
                        st.markdown("#### 👁️ Data Preview")
                        
                        preview_tabs = st.tabs(["Accidents", "Violations", "Locations"])
                        
                        with preview_tabs[0]:
                            col_prev1, col_prev2 = st.columns([3, 1])
                            with col_prev1:
                                st.markdown("**First 5 rows from accidents.csv:**")
                            with col_prev2:
                                st.write(f"Columns: {len(datasets['accidents'].columns)}")
                            st.dataframe(datasets['accidents'].head(5), use_container_width=True, height=250)
                        
                        with preview_tabs[1]:
                            col_prev1, col_prev2 = st.columns([3, 1])
                            with col_prev1:
                                st.markdown("**First 5 rows from violations.csv:**")
                            with col_prev2:
                                st.write(f"Columns: {len(datasets['violations'].columns)}")
                            st.dataframe(datasets['violations'].head(5), use_container_width=True, height=250)
                        
                        with preview_tabs[2]:
                            col_prev1, col_prev2 = st.columns([3, 1])
                            with col_prev1:
                                st.markdown("**First 5 rows from locations.csv:**")
                            with col_prev2:
                                st.write(f"Columns: {len(datasets['locations'].columns)}")
                            st.dataframe(datasets['locations'].head(5), use_container_width=True, height=250)
                        
                        st.markdown("---")
                        st.info("🎉 Your data is ready! Navigate to **🏠 Overview** page to start analyzing.")
                        st.balloons()
        else:
            st.markdown("""
            <div style='padding: 20px; background: rgba(124, 58, 237, 0.1); border-radius: 8px; text-align: center;'>
                <p style='color: #e0e7ff; font-size: 1.1em;'>👆 Upload your 3 CSV files to get started</p>
                <p style='color: #a855f7; font-size: 0.9em;'>Have questions? See the format guide below ⬇️</p>
            </div>
            """, unsafe_allow_html=True)
    
    # ============================================================================
    # HELP & FORMAT GUIDE (At the bottom)
    # ============================================================================
    st.markdown("---")
    st.markdown("### 📚 Need Help? Format Guide")
    
    help_tabs = st.tabs(["📋 File Formats", "📝 Sample Data", "❓ FAQ"])
    
    with help_tabs[0]:
        st.markdown("""
        #### 📄 accidents.csv
        - **Purpose:** Records of traffic accidents
        - **Format:** CSV file with headers
        - **Required Columns:**
          - `location_id` (string) - e.g., "LOC-0001"
          - `date` (string) - Format: YYYY-MM-DD e.g., "2023-06-15"
          - `hour` (integer) - 0-23 e.g., 14
          - `severity` (string) - One of: Minor, Moderate, Severe, Fatal
          - `num_casualties` (integer) - Number of injuries
          - `num_fatalities` (integer) - Number of deaths
          - `primary_vehicle` (string) - e.g., "Car", "Motorcycle"
          - `cause` (string) - e.g., "Over Speeding"
          - `latitude` (float) - GPS latitude
          - `longitude` (float) - GPS longitude
        
        #### 📄 violations.csv
        - **Purpose:** Traffic violation records
        - **Required Columns:**
          - `location_id` (string) - e.g., "LOC-0001"
          - `date` (string) - Format: YYYY-MM-DD
          - `hour` (integer) - 0-23
          - `violation_type` (string) - e.g., "Speeding"
          - `fine_amount` (integer) - Fine amount
          - `vehicle_type` (string) - e.g., "Car"
          - `repeat_offender` (boolean) - true/false
        
        #### 📄 locations.csv
        - **Purpose:** Intersection/location master data
        - **Required Columns:**
          - `location_id` (string) - e.g., "LOC-0001" (MUST match accidents.csv)
          - `location_name` (string) - e.g., "Junction 1"
          - `latitude` (float) - GPS latitude
          - `longitude` (float) - GPS longitude
          - `zone` (string) - e.g., "North Zone"
          - `road_type` (string) - e.g., "Highway"
          - `speed_limit_kmph` (integer) - e.g., 60
          - `num_lanes` (integer) - e.g., 4
          - `has_traffic_signal` (boolean) - true/false
          - `has_cctv` (boolean) - true/false
        """)
    
    with help_tabs[1]:
        st.markdown("""
        #### 📥 Download Sample Files
        Sample CSV files are available in the `data/` folder of your project:
        - `data/accidents.csv` - Download and modify as needed
        - `data/violations.csv` - Use as template
        - `data/locations.csv` - Use as reference
        
        #### ✅ Quick Checklist Before Uploading
        - [ ] All file names are lowercase: `accidents.csv`, `violations.csv`, `locations.csv`
        - [ ] Date format is YYYY-MM-DD (e.g., 2023-06-15)
        - [ ] No special characters in file names
        - [ ] CSV format only (not Excel .xlsx)
        - [ ] No blank rows or columns
        - [ ] All required columns exist
        - [ ] No empty values in required columns
        """)
    
    with help_tabs[2]:
        st.markdown("""
        #### ❓ Frequently Asked Questions
        
        **Q: What if I don't have weather.csv?**  
        A: It's optional! We automatically generate weather data if missing.
        
        **Q: Can I use Excel files (.xlsx)?**  
        A: Currently only CSV files are supported. Convert Excel to CSV first.
        
        **Q: My location_id doesn't match between files?**  
        A: Make sure location_id values are identical across all files.
        
        **Q: What date format should I use?**  
        A: Use YYYY-MM-DD format (e.g., 2023-06-15 for June 15, 2023).
        
        **Q: How many records do I need?**  
        A: Minimum 10-20 locations and 50+ accidents for meaningful analysis. 
           We recommend 100+ locations and 1000+ accidents for best results.
        
        **Q: Can I switch between datasets?**  
        A: Yes! Just come back to this page and upload different files or select Sample Data.
        
        **Q: Is my data saved?**  
        A: No, your data is only in the current session. Refresh the page = data is cleared.
        """)


def main():
    page = render_sidebar()

    # Data Upload page doesn't need data loading
    if page == NAV_DATA_UPLOAD:
        page_data_upload()
    else:
        # Load data for all other pages
        with st.spinner("Loading data and computing risk scores..."):
            datasets = load_data()
            risk_df = compute_risk_data(
                datasets["locations"], datasets["accidents"], datasets["violations"])

        if page == NAV_OVERVIEW:
            page_overview(datasets, risk_df)

        elif page == NAV_RISK_MAP:
            page_risk_map(risk_df)

        elif page == NAV_TRENDS:
            page_trends(datasets)

        elif page == NAV_PREDICTION:
            with st.spinner("Training ML models (this may take a moment)..."):
                features_df, result_rf, result_gb, result_lr, comparison = \
                    train_model(datasets["accidents"], datasets["violations"],
                                datasets["locations"])
            page_prediction(features_df, result_rf, result_gb, result_lr, comparison)

        elif page == NAV_PREVENTION:
            page_prevention(risk_df)

        elif page == NAV_RESOURCES:
            page_resources(risk_df)


if __name__ == "__main__":
    main()
