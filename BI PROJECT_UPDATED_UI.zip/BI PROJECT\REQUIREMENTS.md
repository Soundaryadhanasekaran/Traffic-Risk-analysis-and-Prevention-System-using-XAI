# Software Requirements - Smart Traffic Risk Prediction System

## System Requirements
• Windows 10/11, macOS 10.14+, or Linux Ubuntu 18.04+
• Intel Core i5 or equivalent processor
• 8GB RAM minimum (16GB recommended)
• 2GB free disk space
• Internet connection

## Python & Core Libraries
• Python 3.9 or higher
• NumPy >= 1.24.0
• Pandas >= 2.0.0
• Scikit-learn >= 1.3.0
• pip package manager

## Visualization Libraries
• Plotly >= 5.15.0
• Matplotlib >= 3.7.0
• Seaborn >= 0.12.0
• Folium >= 0.14.0
• Streamlit-Folium >= 0.15.0

## Dashboard & Web Framework
• Streamlit >= 1.28.0

## Explainable AI
• SHAP >= 0.42.0

## Development Tools
• Python IDE or text editor (VS Code, PyCharm, or Jupyter)
• Git (for version control)
• Virtual environment (venv or conda)

## Optional Libraries
• Dask >= 2023.0.0 (parallel computing)
• XGBoost >= 1.7.0 (advanced ML models)
• LightGBM >= 3.3.0 (gradient boosting)
• TensorFlow >= 2.13.0 (deep learning)
• Pytest >= 7.0.0 (testing framework)
• Black >= 23.0.0 (code formatter)

## Web Browsers
• Google Chrome (latest)
• Mozilla Firefox (latest)
• Microsoft Edge (latest)
• Safari (macOS, latest)

## Cloud Deployment (Optional)
• Azure Account (free tier available)
• Azure CLI
• Docker (for containerization)
• Kubernetes (for orchestration)

## Installation Command
```
pip install -r requirements.txt
```

## Run Dashboard
```
streamlit run dashboard/app.py
```
