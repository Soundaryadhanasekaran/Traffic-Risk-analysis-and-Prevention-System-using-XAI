"""
Synthetic Traffic Accident & Violation Data Generator
=====================================================
Generates realistic synthetic data for the Smart Traffic Accident
Risk Prediction and Prevention System.

Datasets produced:
    1. accidents.csv       – Historical accident records
    2. violations.csv      – Traffic violation records
    3. locations.csv       – Intersection / road-segment metadata
    4. weather.csv         – Hourly weather observations
"""

import os
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SEED = 42
NUM_LOCATIONS = 120          # road intersections / segments
NUM_ACCIDENTS = 5000         # accident records over 3 years
NUM_VIOLATIONS = 15000       # violation records over 3 years
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2025, 12, 31)

# Bounding box (approximate metropolitan area – fictional city grid)
LAT_MIN, LAT_MAX = 12.85, 13.15   # e.g., Bangalore-like coordinates
LON_MIN, LON_MAX = 77.50, 77.75

np.random.seed(SEED)


# ---------------------------------------------------------------------------
# 1. Location Master
# ---------------------------------------------------------------------------
def generate_locations(n: int = NUM_LOCATIONS) -> pd.DataFrame:
    """Generate intersection / road-segment master data."""
    location_ids = [f"LOC-{str(i).zfill(4)}" for i in range(1, n + 1)]

    zone_names = ["North Zone", "South Zone", "East Zone", "West Zone", "Central Zone"]
    road_types = ["Highway", "Arterial Road", "Collector Road", "Local Street", "Expressway"]

    lats = np.round(np.random.uniform(LAT_MIN, LAT_MAX, n), 6)
    lons = np.round(np.random.uniform(LON_MIN, LON_MAX, n), 6)

    df = pd.DataFrame({
        "location_id": location_ids,
        "location_name": [f"Junction {i}" for i in range(1, n + 1)],
        "latitude": lats,
        "longitude": lons,
        "zone": np.random.choice(zone_names, n),
        "road_type": np.random.choice(road_types, n, p=[0.10, 0.30, 0.25, 0.25, 0.10]),
        "speed_limit_kmph": np.random.choice([30, 40, 50, 60, 80, 100], n,
                                              p=[0.10, 0.20, 0.25, 0.20, 0.15, 0.10]),
        "num_lanes": np.random.choice([2, 4, 6, 8], n, p=[0.25, 0.35, 0.25, 0.15]),
        "has_traffic_signal": np.random.choice([True, False], n, p=[0.65, 0.35]),
        "has_cctv": np.random.choice([True, False], n, p=[0.45, 0.55]),
        "has_street_light": np.random.choice([True, False], n, p=[0.70, 0.30]),
        "near_school_hospital": np.random.choice([True, False], n, p=[0.25, 0.75]),
    })
    return df


# ---------------------------------------------------------------------------
# 2. Accidents
# ---------------------------------------------------------------------------
def generate_accidents(locations_df: pd.DataFrame,
                       n: int = NUM_ACCIDENTS) -> pd.DataFrame:
    """Generate historical accident records."""
    loc_ids = locations_df["location_id"].values
    # Make some locations "hot spots" by weighting
    weights = np.random.dirichlet(np.ones(len(loc_ids)) * 0.5)

    severity_levels = ["Minor", "Moderate", "Severe", "Fatal"]
    vehicle_types = ["Car", "Motorcycle", "Bus", "Truck", "Auto-Rickshaw", "Bicycle", "Pedestrian"]
    causes = [
        "Over Speeding", "Drunk Driving", "Signal Jumping", "Wrong Lane Driving",
        "Distracted Driving", "Poor Visibility", "Road Condition", "Vehicle Failure",
        "Pedestrian Error", "Weather Conditions"
    ]

    dates = [START_DATE + timedelta(
        seconds=np.random.randint(0, int((END_DATE - START_DATE).total_seconds()))
    ) for _ in range(n)]

    # Hour distribution – more accidents in evening rush & late night
    hour_probs = np.array([
        0.02, 0.01, 0.01, 0.01, 0.01, 0.02, 0.03, 0.05, 0.06, 0.05,
        0.04, 0.04, 0.04, 0.04, 0.05, 0.05, 0.06, 0.07, 0.07, 0.06,
        0.05, 0.05, 0.04, 0.03])
    hour_probs = hour_probs / hour_probs.sum()  # normalise to 1
    hours = np.random.choice(range(24), n, p=hour_probs)

    chosen_locs = np.random.choice(loc_ids, n, p=weights)
    loc_lookup = locations_df.set_index("location_id")

    df = pd.DataFrame({
        "accident_id": [f"ACC-{str(i).zfill(6)}" for i in range(1, n + 1)],
        "location_id": chosen_locs,
        "date": [d.strftime("%Y-%m-%d") for d in dates],
        "hour": hours,
        "day_of_week": [d.strftime("%A") for d in dates],
        "month": [d.month for d in dates],
        "year": [d.year for d in dates],
        "severity": np.random.choice(severity_levels, n, p=[0.40, 0.30, 0.20, 0.10]),
        "num_vehicles_involved": np.random.choice([1, 2, 3, 4, 5], n,
                                                   p=[0.20, 0.45, 0.20, 0.10, 0.05]),
        "num_casualties": np.clip(np.random.poisson(1.2, n), 0, 10),
        "num_fatalities": np.clip(np.random.poisson(0.15, n), 0, 5),
        "primary_vehicle": np.random.choice(vehicle_types, n),
        "cause": np.random.choice(causes, n,
                                   p=[0.18, 0.12, 0.12, 0.08, 0.10,
                                      0.08, 0.08, 0.06, 0.10, 0.08]),
        "road_surface": np.random.choice(["Dry", "Wet", "Muddy", "Icy"], n,
                                          p=[0.55, 0.30, 0.10, 0.05]),
        "light_condition": np.random.choice(["Daylight", "Dawn/Dusk", "Night-Lit", "Night-Unlit"], n,
                                             p=[0.40, 0.10, 0.30, 0.20]),
        "weather": np.random.choice(["Clear", "Rainy", "Foggy", "Cloudy", "Stormy"], n,
                                     p=[0.40, 0.25, 0.10, 0.15, 0.10]),
    })

    df["latitude"] = df["location_id"].map(loc_lookup["latitude"]) + \
                     np.random.normal(0, 0.002, n)
    df["longitude"] = df["location_id"].map(loc_lookup["longitude"]) + \
                      np.random.normal(0, 0.002, n)

    return df.sort_values("date").reset_index(drop=True)


# ---------------------------------------------------------------------------
# 3. Violations
# ---------------------------------------------------------------------------
def generate_violations(locations_df: pd.DataFrame,
                        n: int = NUM_VIOLATIONS) -> pd.DataFrame:
    """Generate traffic violation records."""
    loc_ids = locations_df["location_id"].values
    weights = np.random.dirichlet(np.ones(len(loc_ids)) * 0.4)

    violation_types = [
        "Speeding", "Signal Jumping", "No Helmet", "No Seatbelt",
        "Wrong Side Driving", "Drunk Driving", "Overloading",
        "Using Mobile Phone", "Illegal Parking", "No License"
    ]

    dates = [START_DATE + timedelta(
        seconds=np.random.randint(0, int((END_DATE - START_DATE).total_seconds()))
    ) for _ in range(n)]

    df = pd.DataFrame({
        "violation_id": [f"VIO-{str(i).zfill(6)}" for i in range(1, n + 1)],
        "location_id": np.random.choice(loc_ids, n, p=weights),
        "date": [d.strftime("%Y-%m-%d") for d in dates],
        "hour": np.random.choice(range(24), n),
        "day_of_week": [d.strftime("%A") for d in dates],
        "violation_type": np.random.choice(violation_types, n,
                                            p=[0.20, 0.12, 0.12, 0.08, 0.08,
                                               0.08, 0.06, 0.10, 0.10, 0.06]),
        "fine_amount": np.random.choice([500, 1000, 2000, 5000, 10000], n,
                                         p=[0.30, 0.30, 0.20, 0.12, 0.08]),
        "vehicle_type": np.random.choice(
            ["Car", "Motorcycle", "Bus", "Truck", "Auto-Rickshaw"], n),
        "repeat_offender": np.random.choice([True, False], n, p=[0.20, 0.80]),
    })
    return df.sort_values("date").reset_index(drop=True)


# ---------------------------------------------------------------------------
# 4. Weather (hourly observations)
# ---------------------------------------------------------------------------
def generate_weather(days: int = 365) -> pd.DataFrame:
    """Generate hourly weather data for 1 year (used for real-time scoring)."""
    records = []
    base = datetime(2025, 1, 1)
    conditions = ["Clear", "Rainy", "Foggy", "Cloudy", "Stormy"]
    for d in range(days):
        for h in range(24):
            ts = base + timedelta(days=d, hours=h)
            cond = np.random.choice(conditions, p=[0.40, 0.25, 0.10, 0.15, 0.10])
            temp = round(np.random.normal(28, 5), 1)
            humidity = round(np.clip(np.random.normal(65, 15), 20, 100), 1)
            visibility_km = round(np.clip(np.random.normal(8, 3), 0.5, 15), 1)
            wind_speed = round(np.clip(np.random.normal(12, 6), 0, 50), 1)
            rainfall_mm = round(max(0, np.random.exponential(2) if cond in
                                     ["Rainy", "Stormy"] else 0), 1)
            records.append({
                "datetime": ts.strftime("%Y-%m-%d %H:%M"),
                "date": ts.strftime("%Y-%m-%d"),
                "hour": h,
                "temperature_c": temp,
                "humidity_pct": humidity,
                "visibility_km": visibility_km,
                "wind_speed_kmph": wind_speed,
                "rainfall_mm": rainfall_mm,
                "weather_condition": cond,
            })
    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# Main – generate and save
# ---------------------------------------------------------------------------
def generate_all_data(output_dir: str = "data") -> dict:
    """Generate all datasets and save to CSV."""
    os.makedirs(output_dir, exist_ok=True)

    print("[1/4] Generating location master data ...")
    locations = generate_locations()
    locations.to_csv(os.path.join(output_dir, "locations.csv"), index=False)

    print("[2/4] Generating accident records ...")
    accidents = generate_accidents(locations)
    accidents.to_csv(os.path.join(output_dir, "accidents.csv"), index=False)

    print("[3/4] Generating violation records ...")
    violations = generate_violations(locations)
    violations.to_csv(os.path.join(output_dir, "violations.csv"), index=False)

    print("[4/4] Generating weather observations ...")
    weather = generate_weather()
    weather.to_csv(os.path.join(output_dir, "weather.csv"), index=False)

    print(f"\n✅ All datasets saved to '{output_dir}/' directory.")
    print(f"   Locations : {len(locations):,} records")
    print(f"   Accidents : {len(accidents):,} records")
    print(f"   Violations: {len(violations):,} records")
    print(f"   Weather   : {len(weather):,} records")

    return {
        "locations": locations,
        "accidents": accidents,
        "violations": violations,
        "weather": weather,
    }


if __name__ == "__main__":
    generate_all_data()
